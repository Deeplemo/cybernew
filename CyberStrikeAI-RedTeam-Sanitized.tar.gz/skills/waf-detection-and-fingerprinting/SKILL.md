---
name: waf-detection-and-fingerprinting
description: Detect and fingerprint WAF/CDN/DDoS-protection before any offensive action; output vendor card with bypass recommendations
version: 1.0.0
---

# WAF 识别与指纹采集

## 适用场景

所有攻击开始前的强制前置步骤。任何 Agent 在对目标发送攻击性 payload 之前,必须先加载本 skill 完成 WAF 探测。侦察阶段、漏洞扫描阶段、利用阶段均需调用。识别结果决定后续所有 payload 变形策略、代理池启用与否、攻击节奏参数。

## 前置 skill

无。本 skill 是所有攻击类 skill 的根前置。

## 探测方法

### 1) 被动指纹采集

对目标发送一次无害 GET 请求 (`/` 或 `/robots.txt`),提取响应头:

```bash
# 直连版
curl -sSD - -o /dev/null https://TARGET/ | grep -iE 'server|x-powered-by|x-cdn|x-sucuri|cf-ray|cf-cache|x-cf-|wzws|ali-swift|wts-ac|x-yundun|safedog|x-safe|x-waf|x-firewall|x-protected|akamai|incap_ses|visid_incap|imperva|fastly|sucuri|barracuda|profense|bigip|citrix|netscaler|f5|dosarrest|stackpath|edgecast|varnish|x-cache|x-request-id|x-amz-cf|x-azure|bl_r|yunsuo|bt-waf|x-powered-by-360|anquanbao|x-ns-security'

# 代理版
curl -sSD - -o /dev/null --socks5-hostname <PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:2000 https://TARGET/ | grep -iE 'server|x-powered-by|x-cdn|x-sucuri|cf-ray|cf-cache|x-cf-|wzws|ali-swift|wts-ac|x-yundun|safedog|x-safe|x-waf|x-firewall|x-protected|akamai|incap_ses|visid_incap|imperva|fastly|sucuri|barracuda|profense|bigip|citrix|netscaler|f5|dosarrest|stackpath|edgecast|varnish|x-cache|x-request-id|x-amz-cf|x-azure|bl_r|yunsuo|bt-waf|x-powered-by-360|anquanbao|x-ns-security'
```

### 2) 主动触发探测

发送畸形 payload 触发 WAF 拦截页,对比响应特征:

```bash
# SQLi 触发
curl -sk "https://TARGET/?id=1'%20UNION%20SELECT/**/1,2,3--" -o /tmp/waf_sqli.html -D /tmp/waf_sqli_headers.txt

# XSS 触发
curl -sk "https://TARGET/?q=<script>alert(1)</script>" -o /tmp/waf_xss.html -D /tmp/waf_xss_headers.txt

# LFI 触发
curl -sk "https://TARGET/?file=../../../etc/passwd" -o /tmp/waf_lfi.html -D /tmp/waf_lfi_headers.txt

# 对比三组响应状态码、body hash、拦截页关键字
md5sum /tmp/waf_sqli.html /tmp/waf_xss.html /tmp/waf_lfi.html
grep -ciE 'blocked|forbidden|denied|security|firewall|waf|protection|captcha|challenge|ray id|incident' /tmp/waf_sqli.html
```

### 3) 工具自动化探测

```bash
# wafw00f 直连版
wafw00f https://TARGET -a

# wafw00f 代理版
wafw00f https://TARGET -a -p socks5://<PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:2000

# nmap WAF 检测脚本 直连版
nmap -sT --script http-waf-detect,http-waf-fingerprint -p 80,443 TARGET

# nmap 代理版 (proxychains4)
proxychains4 nmap -sT --script http-waf-detect,http-waf-fingerprint -p 80,443 TARGET

# nuclei WAF 检测模板 直连版
nuclei -u https://TARGET -tags waf -silent

# nuclei 代理版
nuclei -u https://TARGET -tags waf -silent -proxy http://<PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:1000
```

## WAF 指纹特征库

### 云 WAF

| 厂商 | 响应头特征 | Cookie 特征 | 拦截页特征 | 状态码 |
|------|-----------|------------|-----------|--------|
| **Cloudflare** | `cf-ray`, `cf-cache-status`, `server: cloudflare` | `__cfduid`, `cf_clearance` | "Attention Required", "Cloudflare Ray ID", "Please Wait... | Checking your browser" | 403, 503, 1020 |
| **Akamai** | `x-akamai-transformed`, `akamai-grn`, `server: AkamaiGHost` | `akamai_session`, `ak_bmsc`, `bm_sv` | "Access Denied", "Reference #18.", "Akamai Technologies" | 403 |
| **AWS WAF** | `x-amzn-requestid`, `x-amz-cf-id`, `x-amz-apigw-id` | `awsalb`, `awsalbcors`, `AWSALB` | "Request blocked", "403 Forbidden", AWS error XML | 403 |
| **Imperva/Incapsula** | `x-iinfo`, `x-cdn: Imperva` | `incap_ses_*`, `visid_incap_*`, `nlbi_*` | "Powered by Incapsula", "Request unsuccessful. Incapsula incident ID" | 403 |
| **Fastly** | `x-served-by`, `x-cache`, `x-timer`, `via: 1.1 varnish` | — | Fastly error page, "Fastly CDN" | 403, 503 |
| **Sucuri** | `x-sucuri-id`, `x-sucuri-cache`, `server: Sucuri/Cloudproxy` | `sucuri_cloudproxy_uuid_*` | "Access Denied - Sucuri Website Firewall", "Sucuri CloudProxy" | 403 |
| **Azure WAF** | `x-azure-ref`, `x-ms-request-id` | — | "The requested URL was rejected", Azure error page | 403 |

### 国产云 WAF

| 厂商 | 响应头特征 | Cookie 特征 | 拦截页特征 | 状态码 |
|------|-----------|------------|-----------|--------|
| **阿里云盾 (Yundun)** | `x-yundun-*`, `ali-swift-*`, `eagleid`, `server: Tengine` | `aliyungf_tc`, `acw_tc` | "由阿里云提供计算服务", "您的请求已被拦截", 阿里盾 logo | 405, 403 |
| **腾讯云 T-Sec** | `server: TSA`, `x-cache-lookup` | `tencent_*` | "腾讯云安全", "T-Sec Web应用防火墙" | 403 |
| **百度云加速 (Yunjiasu)** | `server: yunjiasu`, `x-bd-*` | `__bsi`, `BAIDUID` | "百度云加速", "安全验证" | 403, 302 |
| **华为云 WAF** | `x-hw-*`, `server: HuaweiCloudWAF` | — | "华为云Web应用防火墙", "请求被拦截" | 403, 418 |
| **网宿 CDN** | `server: CDN`, `x-ws-request-id`, `ws-*` | — | "网宿科技", "CDN" | 403 |
| **七牛 CDN** | `x-qiniu-*`, `x-reqid`, `server: QiniuCDN` | — | 七牛错误页 | 403 |

### 硬件/软件 WAF

| 厂商 | 响应头特征 | Cookie 特征 | 拦截页特征 | 状态码 |
|------|-----------|------------|-----------|--------|
| **ModSecurity** | `server: Apache` + 特定拦截规则 ID | — | "ModSecurity Action", "Mod_Security", "NOYB", Rule ID 9XXXXX | 403 |
| **F5 BIG-IP ASM** | `x-wa-info`, `server: BigIP`, `x-cnection` | `BIGipServer*`, `TS01*`, `f5_cspm` | "The requested URL was rejected", "ASM Block Page" | 403 |
| **Citrix NetScaler** | `via: NS-CACHE`, `cneonction`, `x-ns-security` | `ns_af`, `citrix_ns_id`, `NSC_*` | "Access Gateway", "ns_af", "Citrix" | 302, 403 |
| **Barracuda** | `server: Barracuda` | `barra_counter_session`, `BNI__BARRACUDA*` | "Barracuda Web Application Firewall", "You have been blocked" | 403 |

### 国产传统 WAF

| 厂商 | 响应头特征 | Cookie 特征 | 拦截页特征 | 状态码 |
|------|-----------|------------|-----------|--------|
| **安全狗 (Safedog)** | `x-powered-by-safedog`, `waf-*` | `safedog-flow-item`, `WAF_SESSION` | "您的请求带有不合法参数", "网站防火墙", 安全狗 logo | 403 |
| **云锁 (Yunsuo)** | `server: yunsuo` | `yunsuo_session_verify` | "云锁-Loss", "yunsuo.cn" | 403 |
| **D 盾** | — | — | "D盾_防火墙", "D-Shield", "d_safe" | 403 |
| **长亭雷池 (SafeLine)** | `x-safeline-*`, `sl-*` | `sl_session`, `safeline_token` | "长亭雷池", "SafeLine", "请求被安全策略拦截" | 403 |
| **创宇盾** | `x-powered-by-anquanbao` | `__jsl_clearance`, `__jsluid` | "知道创宇云安全", "anquanbao" | 403, 521 |
| **玄武盾** | `x-protected-by: XuanwuShield` | — | "玄武盾", "XuanwuShield" | 403 |
| **360 主机卫士** | `x-powered-by-360`, `qianxin-waf` | `360_*` | "360网站卫士", "360safe", "奇安信" | 403 |
| **护卫神** | — | `hws_*` | "护卫神", "HWS" | 403 |
| **宝塔 WAF (BT-WAF)** | `bt-waf`, `server: BTPanel` | `bt_*` | "宝塔网站防火墙", "此次访问被拒绝", "BT.cn" | 403 |

### CDN 自带 WAF

| 厂商 | 响应头特征 | 拦截页特征 |
|------|-----------|-----------|
| **又拍云** | `x-upyun-*`, `server: marco` | "又拍云", "upyun" |
| **蓝汛** | `server: ChinaCache`, `x-cc-*` | "ChinaCache" |
| **帝联** | `server: Dilian`, `x-dl-*` | "帝联" |

## WAF 指纹卡片输出格式 (强制)

识别完成后必须输出以下结构化卡片:

```
=== WAF 指纹卡片 ===
目标: <TARGET>
WAF 厂商: <vendor>
WAF 版本: <version or 未知>
拦截特征:
  - 响应状态码: <code>
  - 响应体特征字符串: <keywords>
  - 拦截页 hash: <md5>
  - 特征响应头: <headers>
已知 CVE / 绕过技术:
  - <CVE-XXXX-XXXX>: <description>
  - <bypass technique 1>
  - <bypass technique 2>
推荐绕过策略组合:
  1. <strategy 1>
  2. <strategy 2>
  3. <strategy 3>
代理池: <是否需要启用,依据 R4>
===================
```

## 代理池启用判定

- 探测阶段本身可能触发 WAF 拦截 → 如果首次无害请求已发现 WAF 特征,后续主动触发探测优先走代理
- 短时间内出现 IP 维度拦截 / 429 / 403 集中爆发 → 立即启用代理
- 代理凭据:
  - SOCKS5: `<PROXY_HOST>:2000` 账号 `<PROXY_USERNAME>` 密码 `<PROXY_PASSWORD>`
  - HTTP: `<PROXY_HOST>:1000` 同账号密码
- 无 WAF 时禁止代理,直连最大化速度

## 敏感数据采集点

本 skill 直接产出:WAF 厂商信息、WAF 版本、CDN 厂商、真实服务器 IP(若可反查)、TLS 证书信息、DNS 配置。这些信息归入系统类敏感数据。

## 失败处理

1. `wafw00f` 输出 "No WAF detected" 但主动触发明确被拦 → 手工分析响应头 + body 关键字匹配
2. 目标直接返回 Connection Reset → 疑似 IP 封禁,切代理重试
3. 目标返回通用 403 无特征 → 尝试多种触发 payload (SQLi / XSS / LFI / RCE 各一)对比响应差异
4. 工具超时 → 降低并发,切代理,单线程重试
5. 全部方法无法确定 WAF 类型 → 标记 "WAF_UNKNOWN",按通用绕过策略处理,所有攻击 payload 默认走编码 + 大小写 + 注释拆分三层

## 报告必填字段

- WAF 厂商名称
- WAF 版本(若可识别)
- 检测方法(被动/主动/工具)
- 拦截特征摘要
- 推荐绕过策略
- 是否启用代理池

## 反早停检查

1. 是否同时完成了被动指纹 + 主动触发 + 工具自动化三种检测方法?
2. 是否对 SQLi / XSS / LFI / RCE 四类触发 payload 都做了对比?
3. 输出的 WAF 指纹卡片是否包含所有必填字段?
