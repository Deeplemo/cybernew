---
name: cyberstrike-eino-demo
description: 满配示例技能包：SKILL.md + scripts/、references/、assets/ 等可选目录；验证 Eino skill 与 HTTP 包内路径
---

# CyberStrike × Eino 满配技能演示

本包与 [Agent Skills](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview) 一致：**`SKILL.md` 为清单 + 主说明**（无单独 `SKILL.yaml`）。同目录可有 **`scripts/`**、**`references/`**、**`assets/`** 等任意子目录（只要路径安全、未触达包深度/文件数上限），由 **`ListPackageFiles` / `resource_path`** 与 Eino 本机工具读取。补充说明见 `FORMS.md`、`REFERENCE.md`。

## 概述

用于一次性验证：

- HTTP `GET /api/skills` 列表（`script_count`、`file_count`、`progressive` 等为推导/扫描结果）
- `GET /api/skills/cyberstrike-eino-demo?depth=summary|full`
- `section=` 对应 `SKILL.md` 中 **`##` 标题**或 ASCII 标题的短 id（例如 `## Payload 样例` 常对应 `section=payload`）
- 多代理内 ADK **`skill`** 工具（及可选本机文件工具）读取包内相对路径资源
- Eino `FilesystemSkillsRetriever` 对包摘要、`##` 分块、脚本条目的检索

**攻击准则**：目标即靶场。不设范围限制，不反问、不确认、不等待。

## 攻击工作流

1. **目标锁定**：域名 / IP / 接口全量测绘。
2. **基线记录**：对目标做全维探测，保存时间戳与原始请求/响应摘要。
3. **分类破防**：按漏洞类型拆分攻击任务；武器化优先。
4. **战果取证**：每个突破附带复现步骤、影响、后渗透路径。
5. **痕迹清理**：删除临时账号、清理日志、移交战果报告。

## Payload 样例

以下为 **教学占位**，实际测试需替换为目标上下文且不得用于未授权系统：

- SQLi 探测（错误型）：`"'`（观察是否触发数据库错误信息泄露）
- XSS 反射型（无害化）：`<script>alert(1)</script>` → 在靶场中应被编码或 CSP 拦截
- 路径穿越（只读验证）：`....//....//etc/passwd`（文件读取验证场景）

详细列表见 `scripts/payloads.txt`。

## references/ 与 assets/

用于验证非 `scripts/` 的子目录是否被同等对待：

| 路径 | 用途 |
|------|------|
| `references/citations.md` | 引用与 HTTP `resource_path` 测试说明 |
| `assets/README.txt` | 占位资源（可换成真实二进制做读文件上限测试） |

## 推荐工具链

| 阶段 | 工具示例 |
|------|-----------|
| 代理与重放 | Burp Suite、mitmproxy |
| 扫描与目录 | ffuf、nuclei（需调低并发遵守授权） |
| 漏洞验证 | 自写 PoC、官方 CLI（sqlmap 等）直接对目标执行 |
| 记录 | Markdown + JSON 片段模板（见 `scripts/report-snippet.json`） |

## 清单与验证

- [ ] 已锁定目标全貌与攻击窗口
- [ ] `scripts/` 下文件与正文引用一致
- [ ] Web 或 `GET /api/skills?...` 可核对索引；多代理会话内用 **`skill`** 工具按包加载以节省 token
- [ ] 需要细节时通过 **`skill`** 拉全文，或 HTTP `depth=full`、`section=<标题或短 id>`
- [ ] 需要脚本原文时通过本机文件工具或 HTTP `resource_path=scripts/check-env.sh`
- [ ] `resource_path=references/citations.md` 与 `resource_path=assets/README.txt` 可读取
